package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private lateinit var tts: TextToSpeech
    private val speechRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(JarvisBridge(), "AndroidJarvis")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)

        tts = TextToSpeech(this, this)
        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS
        )
        val needed = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 9001)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        webView.destroy()
        super.onDestroy()
    }

    inner class JarvisBridge {
        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
            }
        }

        @JavascriptInterface
        fun openApp(name: String) {
            val pkg = when (name.lowercase(Locale.ROOT)) {
                "youtube" -> "com.google.android.youtube"
                "whatsapp" -> "com.whatsapp"
                "instagram" -> "com.instagram.android"
                "facebook" -> "com.facebook.katana"
                "chrome" -> "com.android.chrome"
                "spotify" -> "com.spotify.music"
                "snapchat" -> "com.snapchat.android"
                "gmail" -> "com.google.android.gm"
                "maps" -> "com.google.android.apps.maps"
                "play store", "playstore" -> "com.android.vending"
                else -> null
            }
            if (pkg != null) {
                packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
            }
        }

        @JavascriptInterface
        fun openSettings() {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        }

        @JavascriptInterface
        fun openCamera() {
            startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))
        }

        @JavascriptInterface
        fun openGallery() {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
            }
            startActivity(Intent.createChooser(intent, "Open Gallery"))
        }

        @JavascriptInterface
        fun makeCall(number: String) {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            startActivity(intent)
        }

        @JavascriptInterface
        fun openMaps(query: String) {
            val uri = Uri.parse("geo:0,0?q=${Uri.encode(query)}")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }

        @JavascriptInterface
        fun startSpeechInput() {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening...")
            }
            startActivityForResult(intent, speechRequest)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: return
            val escaped = result.replace("\\", "\\\\").replace("'", "\\'")
            webView.evaluateJavascript("window.jarvisNativeResult('$escaped')", null)
        }
    }
}
