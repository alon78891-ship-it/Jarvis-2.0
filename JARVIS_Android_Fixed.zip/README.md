# JARVIS Android - Fixed Build

This version is corrected for GitHub Actions APK building.

## Build
- Android Gradle Plugin 8.7.3
- Gradle 8.10.2
- Kotlin 2.0.21
- compileSdk 35
- minSdk 26
- No AppCompat dependency required

## Important
This is a working Android foundation with native speech input, TTS, app launching,
camera/gallery/settings/maps commands and the JARVIS UI.

Advanced features such as a true wake word, AI image generation, live camera vision,
WhatsApp automatic sending, accessibility automation, weather API, and authorized
voice cloning require additional APIs/native modules and permissions.
