package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.service.MathEvaluator
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JARVIS", appName)
    }

    @Test
    fun `test math evaluator basic and compound expressions`() {
        val res1 = MathEvaluator.evaluate("25 * 40")
        assertEquals(1000.0, res1, 0.001)

        val res2 = MathEvaluator.evaluate("10 + 20 * 3")
        assertEquals(70.0, res2, 0.001)

        val res3 = MathEvaluator.evaluate("(10 + 20) * 3")
        assertEquals(90.0, res3, 0.001)
    }
}
