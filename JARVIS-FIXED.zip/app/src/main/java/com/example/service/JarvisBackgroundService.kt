package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.example.MainActivity
import com.example.R
import com.example.data.api.ExternalServices
import com.example.data.api.GroqApiService
import com.example.data.db.JarvisDatabase
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import com.example.ui.VoiceTriggerActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class JarvisBackgroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var notificationManager: NotificationManager
    private lateinit var deviceController: DeviceController
    private lateinit var externalServices: ExternalServices
    private lateinit var groqService: GroqApiService
    private lateinit var db: JarvisDatabase
    private lateinit var prefs: SharedPreferences
    private lateinit var smartCommander: JarvisSmartCommander
    private var voiceManager: VoiceAssistantManager? = null

    private var lastUserMessage: String = ""
    private var lastJarvisMessage: String = "JARVIS Online in Background. Ready for commands."

    companion object {
        const val CHANNEL_ID = "jarvis_background_protocol"
        const val NOTIFICATION_ID = 1001
        const val KEY_TEXT_REPLY = "key_jarvis_direct_reply"

        const val ACTION_START = "com.example.jarvis.ACTION_START"
        const val ACTION_STOP = "com.example.jarvis.ACTION_STOP"
        const val ACTION_PROCESS_REPLY = "com.example.jarvis.ACTION_PROCESS_REPLY"
        const val ACTION_TOGGLE_TORCH = "com.example.jarvis.ACTION_TOGGLE_TORCH"

        fun startService(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        deviceController = DeviceController(this)
        externalServices = ExternalServices()
        groqService = GroqApiService()
        db = JarvisDatabase.getInstance(this)
        prefs = getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

        val savedApiKey = prefs.getString("groq_api_key", GroqApiService.DEFAULT_API_KEY) ?: GroqApiService.DEFAULT_API_KEY
        groqService.updateApiKey(savedApiKey)

        val lang = prefs.getString("preferred_language", "hi") ?: "hi"
        voiceManager = VoiceAssistantManager(this) { _ -> }
        voiceManager?.preferredLanguage = lang

        smartCommander = JarvisSmartCommander(
            dao = db.jarvisDao(),
            deviceController = deviceController,
            externalServices = externalServices,
            groqService = groqService,
            getUserName = { prefs.getString("user_name", "Boss") ?: "Boss" },
            getPreferredLang = { prefs.getString("preferred_language", "hi") ?: "hi" }
        )

        createNotificationChannel()
        JarvisChatBridge.setBackgroundActive(true)

        // Observe incoming background voice commands from Bridge
        serviceScope.launch {
            JarvisChatBridge.incomingBackgroundCommands.collect { cmd ->
                processBackgroundCommand(cmd)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_PROCESS_REPLY -> {
                val remoteInput = RemoteInput.getResultsFromIntent(intent)
                val replyText = remoteInput?.getCharSequence(KEY_TEXT_REPLY)?.toString()
                if (!replyText.isNullOrBlank()) {
                    processBackgroundCommand(replyText.trim())
                }
            }

            ACTION_TOGGLE_TORCH -> {
                val currentTorch = deviceController.isTorchActive()
                deviceController.setFlashlight(!currentTorch)
                val statusText = if (!currentTorch) "Flashlight On kar di" else "Flashlight Off kar di"
                lastJarvisMessage = statusText
                updateNotification()
                voiceManager?.speak(statusText)
            }

            ACTION_START, null -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                val userName = prefs.getString("user_name", "Boss") ?: "Boss"
                val welcome = "JARVIS background protocol online hai, $userName. Main background me sunne aur bolne ke liye ready hu."
                voiceManager?.speak(welcome)
            }
        }

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Background Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Ongoing notification for JARVIS background voice and chatting power"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 1. Direct Reply Action (Type or speak on keyboard)
        val remoteInput = RemoteInput.Builder(KEY_TEXT_REPLY)
            .setLabel("Reply to JARVIS...")
            .build()

        val replyIntent = Intent(this, JarvisNotificationReceiver::class.java).apply {
            action = ACTION_PROCESS_REPLY
        }
        val replyPendingIntent = PendingIntent.getBroadcast(
            this,
            1,
            replyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        val replyAction = NotificationCompat.Action.Builder(
            R.drawable.ic_launcher_foreground,
            "💬 Quick Chat",
            replyPendingIntent
        ).addRemoteInput(remoteInput).build()

        // 2. Instant Voice Command Action (launches VoiceTriggerActivity)
        val voiceIntent = Intent(this, VoiceTriggerActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val voicePendingIntent = PendingIntent.getActivity(
            this,
            4,
            voiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val voiceAction = NotificationCompat.Action.Builder(
            R.drawable.ic_launcher_foreground,
            "🎤 Speak",
            voicePendingIntent
        ).build()

        // 3. Torch Action
        val torchIntent = Intent(this, JarvisNotificationReceiver::class.java).apply {
            action = ACTION_TOGGLE_TORCH
        }
        val torchPendingIntent = PendingIntent.getBroadcast(
            this,
            2,
            torchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val torchAction = NotificationCompat.Action.Builder(
            R.drawable.ic_launcher_foreground,
            if (deviceController.isTorchActive()) "💡 Torch Off" else "💡 Torch On",
            torchPendingIntent
        ).build()

        // 4. Stop Action
        val stopIntent = Intent(this, JarvisNotificationReceiver::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            this,
            3,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = NotificationCompat.Action.Builder(
            R.drawable.ic_launcher_foreground,
            "🛑 Stop",
            stopPendingIntent
        ).build()

        val contentBody = if (lastUserMessage.isNotBlank()) {
            "You: $lastUserMessage\nJARVIS: $lastJarvisMessage"
        } else {
            lastJarvisMessage
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("⚡ JARVIS Background Active")
            .setContentText(lastJarvisMessage)
            .setStyle(NotificationCompat.BigTextStyle().bigText(contentBody))
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .addAction(voiceAction)
            .addAction(replyAction)
            .addAction(torchAction)
            .addAction(stopAction)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification() {
        notificationManager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun processBackgroundCommand(rawInput: String) {
        lastUserMessage = rawInput
        val userMsg = ChatMessage(role = MessageRole.USER, text = rawInput)
        JarvisChatBridge.addMessage(userMsg)

        serviceScope.launch(Dispatchers.IO) {
            val result = smartCommander.execute(rawInput, hasCallPermission = true)
            lastJarvisMessage = result.replyText

            val jarvisMsg = ChatMessage(
                role = MessageRole.JARVIS,
                text = result.replyText,
                commandTag = result.commandTag,
                isError = result.isError
            )
            JarvisChatBridge.addMessage(jarvisMsg)

            serviceScope.launch(Dispatchers.Main) {
                // Speaks aloud through speakers/headphones in background!
                voiceManager?.speak(result.spokenText)
                updateNotification()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        JarvisChatBridge.setBackgroundActive(false)
        voiceManager?.shutdown()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
