package com.example.service

import java.util.Stack

object MathEvaluator {
    fun evaluate(expression: String): Double {
        val sanitized = expression.replace(" ", "")
        val tokens = tokenize(sanitized)
        return parseTokens(tokens)
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        while (i < expr.length) {
            val c = expr[i]
            if (c in "+-*/()^%") {
                tokens.add(c.toString())
                i++
            } else if (c.isDigit() || c == '.') {
                val sb = java.lang.StringBuilder()
                while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i])
                    i++
                }
                tokens.add(sb.toString())
            } else {
                i++
            }
        }
        return tokens
    }

    private fun parseTokens(tokens: List<String>): Double {
        val values = Stack<Double>()
        val ops = Stack<Char>()

        var i = 0
        while (i < tokens.size) {
            val token = tokens[i]
            when {
                token.toDoubleOrNull() != null -> {
                    values.push(token.toDouble())
                }
                token == "(" -> {
                    ops.push('(')
                }
                token == ")" -> {
                    while (ops.isNotEmpty() && ops.peek() != '(') {
                        values.push(applyOp(ops.pop(), values.pop(), values.pop()))
                    }
                    if (ops.isNotEmpty()) ops.pop() // remove '('
                }
                token in listOf("+", "-", "*", "/", "%", "^") -> {
                    val op = token[0]
                    while (ops.isNotEmpty() && hasPrecedence(op, ops.peek())) {
                        values.push(applyOp(ops.pop(), values.pop(), values.pop()))
                    }
                    ops.push(op)
                }
            }
            i++
        }

        while (ops.isNotEmpty()) {
            values.push(applyOp(ops.pop(), values.pop(), values.pop()))
        }

        return if (values.isNotEmpty()) values.pop() else 0.0
    }

    private fun hasPrecedence(op1: Char, op2: Char): Boolean {
        if (op2 == '(' || op2 == ')') return false
        if ((op1 == '*' || op1 == '/' || op1 == '%') && (op2 == '+' || op2 == '-')) return false
        if (op1 == '^' && op2 != '^') return false
        return true
    }

    private fun applyOp(op: Char, b: Double, a: Double): Double {
        return when (op) {
            '+' -> a + b
            '-' -> a - b
            '*' -> a * b
            '/' -> if (b != 0.0) a / b else Double.NaN
            '%' -> a % b
            '^' -> Math.pow(a, b)
            else -> 0.0
        }
    }
}
