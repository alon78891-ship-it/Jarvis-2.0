package com.example.service

import android.app.AlarmManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import java.net.URLEncoder

class DeviceController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private var torchActive = false

    // 1. BATTERY STATUS
    fun getBatteryInfo(): Pair<Int, String> {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, filter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val statusInt = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
            val statusStr = when (statusInt) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
                else -> "Normal"
            }
            Pair(pct, statusStr)
        } catch (e: Exception) {
            Pair(100, "Unknown")
        }
    }

    // 2. FLASHLIGHT / TORCH
    fun setFlashlight(enabled: Boolean): Boolean {
        return try {
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return false
            cameraManager.setTorchMode(cameraId, enabled)
            torchActive = enabled
            true
        } catch (e: Exception) {
            false
        }
    }

    fun isTorchActive(): Boolean = torchActive

    // 3. VOLUME CONTROL
    fun adjustVolume(up: Boolean): Int {
        try {
            audioManager?.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (_: Exception) {}
        return getCurrentVolumePercent()
    }

    fun getCurrentVolumePercent(): Int {
        return try {
            val current = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 5
            val max = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
            (current * 100) / max
        } catch (e: Exception) {
            50
        }
    }

    // 4. PHONE CALLS
    fun makePhoneCall(number: String, hasCallPermission: Boolean): Boolean {
        return try {
            val clean = number.replace(" ", "").replace("-", "")
            val uri = Uri.parse("tel:$clean")
            val intent = if (hasCallPermission) {
                Intent(Intent.ACTION_CALL, uri)
            } else {
                Intent(Intent.ACTION_DIAL, uri)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // fallback to dial
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(dialIntent)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    // 5. WHATSAPP MESSAGE & CHAT
    fun sendWhatsApp(number: String, message: String): Boolean {
        return try {
            var formatted = number.replace(" ", "").replace("-", "")
            if (!formatted.startsWith("+") && !formatted.startsWith("91") && formatted.length == 10) {
                formatted = "91$formatted"
            }
            formatted = formatted.removePrefix("+")

            val encodedMsg = URLEncoder.encode(message, "UTF-8")
            val url = "https://wa.me/$formatted?text=$encodedMsg"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openWhatsAppChat(number: String): Boolean {
        return try {
            var formatted = number.replace(" ", "").replace("-", "")
            if (!formatted.startsWith("+") && !formatted.startsWith("91") && formatted.length == 10) {
                formatted = "91$formatted"
            }
            formatted = formatted.removePrefix("+")
            val url = "https://wa.me/$formatted"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // 6. UNIVERSAL APP OPENER
    fun openApp(appName: String): Boolean {
        val target = appName.lowercase().trim()
        val pm = context.packageManager

        // Known standard packages
        val packageMap = mapOf(
            "camera" to "com.google.android.GoogleCamera",
            "gallery" to "com.google.android.apps.photos",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "youtube" to "com.google.android.youtube",
            "google" to "com.google.android.googlequicksearchbox",
            "chrome" to "com.android.chrome",
            "calculator" to "com.google.android.calculator",
            "settings" to "com.android.settings"
        )

        // Try direct intent by intent action
        try {
            when (target) {
                "camera" -> {
                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    return true
                }
                "gallery" -> {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        type = "image/*"
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    return true
                }
                "settings" -> {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    return true
                }
            }
        } catch (_: Exception) {}

        // Try launching package directly
        val pkg = packageMap[target]
        if (pkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return true
            }
        }

        // Web URL fallbacks for web-capable apps
        val webFallbacks = mapOf(
            "whatsapp" to "https://wa.me/",
            "instagram" to "https://instagram.com",
            "youtube" to "https://youtube.com",
            "google" to "https://google.com",
            "chrome" to "https://google.com"
        )

        val webUrl = webFallbacks[target]
        if (webUrl != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            } catch (_: Exception) {}
        }

        return false
    }

    // 7. ALARM
    fun setAlarm(hour: Int, minute: Int, message: String = "JARVIS Alarm"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // 8. LOCATION
    fun openLocationMap(query: String = ""): Boolean {
        return try {
            val uri = if (query.isNotBlank()) {
                Uri.parse("https://maps.google.com/?q=" + URLEncoder.encode(query, "UTF-8"))
            } else {
                Uri.parse("geo:0,0?q=current+location")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // 9. GOOGLE SEARCH
    fun openGoogleSearch(query: String): Boolean {
        return try {
            val url = "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // 10. YOUTUBE SONG SEARCH
    fun playSongOnYouTube(song: String): Boolean {
        return try {
            val encoded = URLEncoder.encode(song, "UTF-8")
            val appUri = Uri.parse("vnd.youtube:$encoded")
            val intent = Intent(Intent.ACTION_VIEW, appUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            try {
                val webUrl = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(song, "UTF-8")
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    // 11. CLIPBOARD
    fun copyToClipboard(text: String): Boolean {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = ClipData.newPlainText("JARVIS", text)
            clipboard?.setPrimaryClip(clip)
            true
        } catch (e: Exception) {
            false
        }
    }

    // 12. VIBRATION
    fun vibrate(durationMs: Long = 400) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }
}
