package com.example.service

import com.example.data.model.ChatMessage
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object JarvisChatBridge {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isBackgroundActive = MutableStateFlow(false)
    val isBackgroundActive: StateFlow<Boolean> = _isBackgroundActive.asStateFlow()

    private val _incomingBackgroundCommands = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val incomingBackgroundCommands: SharedFlow<String> = _incomingBackgroundCommands.asSharedFlow()

    fun setBackgroundActive(active: Boolean) {
        _isBackgroundActive.value = active
    }

    fun addMessage(message: ChatMessage) {
        _messages.value = _messages.value + message
    }

    fun setMessages(list: List<ChatMessage>) {
        _messages.value = list
    }

    fun clearMessages() {
        _messages.value = emptyList()
    }

    suspend fun dispatchBackgroundCommand(command: String) {
        _incomingBackgroundCommands.emit(command)
    }
}
