package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {
    // --- NOTES ---
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotesFlow(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    suspend fun getAllNotes(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)

    @Query("DELETE FROM notes")
    suspend fun clearNotes()

    // --- TASKS ---
    @Query("SELECT * FROM tasks ORDER BY timestamp DESC")
    fun getAllTasksFlow(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY timestamp DESC")
    suspend fun getAllTasks(): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    @Query("DELETE FROM tasks")
    suspend fun clearTasks()

    // --- MEMORY / BRAIN ---
    @Query("SELECT * FROM memory ORDER BY timestamp DESC")
    fun getAllMemoryFlow(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memory")
    suspend fun getAllMemory(): List<MemoryEntity>

    @Query("SELECT value FROM memory WHERE `key` = :key COLLATE NOCASE LIMIT 1")
    suspend fun getMemoryValue(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun remember(memory: MemoryEntity)

    @Query("DELETE FROM memory WHERE `key` = :key")
    suspend fun deleteMemory(key: String)

    @Query("DELETE FROM memory")
    suspend fun clearMemory()

    // --- CONTACTS ---
    @Query("SELECT * FROM contacts ORDER BY name ASC")
    fun getAllContactsFlow(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts")
    suspend fun getAllContacts(): List<ContactEntity>

    @Query("SELECT phoneNumber FROM contacts WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun getPhoneNumberByName(name: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactEntity)

    @Query("DELETE FROM contacts WHERE name = :name")
    suspend fun deleteContact(name: String)
}
