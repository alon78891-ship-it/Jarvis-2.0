package com.example.data.model

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: MessageRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val commandTag: String? = null,
    val isSpeaking: Boolean = false,
    val isError: Boolean = false
)

enum class MessageRole {
    USER,
    JARVIS,
    SYSTEM
}

enum class JarvisVoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

data class SystemStatus(
    val batteryPercent: Int = 100,
    val batteryStatus: String = "Normal",
    val isTorchOn: Boolean = false,
    val volumeLevel: Int = 50,
    val speechState: JarvisVoiceState = JarvisVoiceState.IDLE,
    val groqStatus: String = "Online",
    val currentListeningAmplitude: Float = 0f
)

data class CommandGuideItem(
    val command: String,
    val title: String,
    val description: String,
    val category: String,
    val example: String
)
