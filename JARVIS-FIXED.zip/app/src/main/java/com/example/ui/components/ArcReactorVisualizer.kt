package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JarvisVoiceState
import com.example.ui.theme.JarvisCyanLight
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGoldAccent
import com.example.ui.theme.JarvisRedAlert
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorVisualizer(
    state: JarvisVoiceState,
    amplitude: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")

    // Rotation angles
    val rotationFast by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot_fast"
    )

    val rotationSlow by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot_slow"
    )

    // Breathing pulse
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val primaryGlowColor = when (state) {
        JarvisVoiceState.LISTENING -> JarvisGoldAccent
        JarvisVoiceState.PROCESSING -> Color(0xFFBD00FF)
        JarvisVoiceState.SPEAKING -> JarvisCyanLight
        JarvisVoiceState.IDLE -> JarvisCyanPrimary
    }

    Box(
        modifier = modifier
            .size(170.dp)
            .testTag("arc_reactor_core")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2f) - 12.dp.toPx()

            // 1. Outer Glow halo
            val glowMultiplier = if (state == JarvisVoiceState.LISTENING) {
                1f + (amplitude * 0.4f)
            } else if (state == JarvisVoiceState.SPEAKING) {
                pulse
            } else {
                1f
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlowColor.copy(alpha = 0.35f),
                        primaryGlowColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.35f * glowMultiplier
                ),
                radius = baseRadius * 1.35f * glowMultiplier,
                center = center
            )

            // 2. Outer segmented tech ring (rotating clockwise)
            rotate(rotationFast, pivot = center) {
                val segments = 12
                val sweep = 360f / segments
                for (i in 0 until segments) {
                    val startAngle = i * sweep
                    drawArc(
                        color = primaryGlowColor.copy(alpha = if (i % 2 == 0) 0.85f else 0.35f),
                        startAngle = startAngle,
                        sweepAngle = sweep * 0.65f,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius, center.y - baseRadius),
                        size = Size(baseRadius * 2, baseRadius * 2),
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // 3. Middle ring with tick marks (rotating counter-clockwise)
            val midRadius = baseRadius * 0.78f
            rotate(rotationSlow, pivot = center) {
                drawCircle(
                    color = primaryGlowColor.copy(alpha = 0.25f),
                    radius = midRadius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                val tickCount = 24
                for (i in 0 until tickCount) {
                    val angle = (i * (360f / tickCount)) * (PI / 180.0)
                    val r1 = midRadius - 4.dp.toPx()
                    val r2 = midRadius + 4.dp.toPx()
                    val p1 = Offset(center.x + (r1 * cos(angle)).toFloat(), center.y + (r1 * sin(angle)).toFloat())
                    val p2 = Offset(center.x + (r2 * cos(angle)).toFloat(), center.y + (r2 * sin(angle)).toFloat())
                    drawLine(
                        color = primaryGlowColor.copy(alpha = if (i % 4 == 0) 0.9f else 0.4f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 4 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 4. Inner Reactor Tri-Core or Hex Core
            val innerRadius = baseRadius * 0.48f * glowMultiplier
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlowColor.copy(alpha = 0.8f),
                        primaryGlowColor.copy(alpha = 0.2f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = innerRadius * 1.2f
                ),
                radius = innerRadius,
                center = center
            )

            // Inner solid ring
            drawCircle(
                color = primaryGlowColor,
                radius = innerRadius,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Center glowing core dot
            val coreDotRadius = (innerRadius * 0.35f) * (if (state == JarvisVoiceState.LISTENING) 1f + amplitude else pulse)
            drawCircle(
                color = Color.White,
                radius = coreDotRadius,
                center = center
            )
        }

        // Overlay status text
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(118.dp))
            val statusLabel = when (state) {
                JarvisVoiceState.LISTENING -> "LISTENING..."
                JarvisVoiceState.PROCESSING -> "PROCESSING..."
                JarvisVoiceState.SPEAKING -> "SPEAKING..."
                JarvisVoiceState.IDLE -> "JARVIS ONLINE"
            }
            Text(
                text = statusLabel,
                color = primaryGlowColor,
                fontSize = 10.sp,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
