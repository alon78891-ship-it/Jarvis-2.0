package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.model.JarvisVoiceState
import com.example.ui.components.ArcReactorVisualizer
import com.example.ui.components.ContactsDialog
import com.example.ui.components.MemoryBrainDialog
import com.example.ui.components.NotesDialog
import com.example.ui.components.QuickCommandsDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.components.SystemHudBar
import com.example.ui.components.TasksDialog
import com.example.ui.components.TerminalFeed
import com.example.ui.components.VoiceControlBar
import com.example.ui.theme.JarvisBackground
import com.example.ui.viewmodel.JarvisViewModel
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@Composable
fun JarvisMainScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val systemStatus by viewModel.systemStatus.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val groqApiKey by viewModel.groqApiKey.collectAsState()
    val preferredLanguage by viewModel.preferredLanguage.collectAsState()
    val isBackgroundActive by viewModel.isBackgroundActive.collectAsState()

    val notes by viewModel.notesFlow.collectAsState()
    val tasks by viewModel.tasksFlow.collectAsState()
    val memory by viewModel.memoryFlow.collectAsState()
    val contacts by viewModel.contactsFlow.collectAsState()

    // Dialog state
    var showCommandsDialog by remember { mutableStateOf(false) }
    var showNotesDialog by remember { mutableStateOf(false) }
    var showTasksDialog by remember { mutableStateOf(false) }
    var showMemoryDialog by remember { mutableStateOf(false) }
    var showContactsDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Check permissions
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
        if (isGranted) {
            startSpeechListening(viewModel)
        }
    }

    val hasCallPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CALL_PHONE
    ) == PackageManager.PERMISSION_GRANTED

    // Photo picker for AI Vision
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    viewModel.analyzeImageFromStream(stream)
                }
            } catch (_: Exception) {}
        }
    }

    val cameraPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val bos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val bis = ByteArrayInputStream(bos.toByteArray())
            viewModel.analyzeImageFromStream(bis)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = JarvisBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(JarvisBackground),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top HUD Bar with Background Chat button
            SystemHudBar(
                systemStatus = systemStatus,
                userName = userName,
                isBackgroundActive = isBackgroundActive,
                onToggleBackgroundService = { viewModel.toggleBackgroundService(context) },
                onToggleTorch = {
                    viewModel.deviceController.setFlashlight(!systemStatus.isTorchOn)
                    viewModel.updateDeviceStatus()
                },
                onStopSpeech = { viewModel.stopSpeaking() },
                onOpenCommands = { showCommandsDialog = true },
                onOpenSettings = { showSettingsDialog = true },
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )

            // 2. Arc Reactor Hero Core
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                ArcReactorVisualizer(
                    state = systemStatus.speechState,
                    amplitude = systemStatus.currentListeningAmplitude,
                    onClick = {
                        if (systemStatus.speechState == JarvisVoiceState.LISTENING) {
                            viewModel.voiceManager.stopListening()
                            viewModel.setVoiceState(JarvisVoiceState.IDLE)
                        } else {
                            if (hasAudioPermission) {
                                startSpeechListening(viewModel)
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                )
            }

            // 3. Holographic Message List / Terminal Log
            TerminalFeed(
                messages = messages,
                onSpeakMessage = { text -> viewModel.speak(text) },
                onCopyMessage = { text -> viewModel.deviceController.copyToClipboard(text) },
                modifier = Modifier.weight(1f)
            )

            // 4. Voice & Command Control Bar
            VoiceControlBar(
                voiceState = systemStatus.speechState,
                amplitude = systemStatus.currentListeningAmplitude,
                onMicClick = {
                    if (systemStatus.speechState == JarvisVoiceState.LISTENING) {
                        viewModel.voiceManager.stopListening()
                        viewModel.setVoiceState(JarvisVoiceState.IDLE)
                    } else {
                        if (hasAudioPermission) {
                            startSpeechListening(viewModel)
                        } else {
                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                },
                onSendCommand = { cmd -> viewModel.processCommand(cmd, hasCallPermission) },
                onPickImage = {
                    photoPickerLauncher.launch(
                        androidx.activity.result.PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageOnly
                        )
                    )
                },
                onOpenNotes = { showNotesDialog = true },
                onOpenTasks = { showTasksDialog = true },
                onOpenMemory = { showMemoryDialog = true },
                onOpenContacts = { showContactsDialog = true },
                onToggleBackgroundService = { viewModel.toggleBackgroundService(context) }
            )
        }
    }

    // --- DIALOGS ---
    if (showCommandsDialog) {
        QuickCommandsDialog(
            onDismiss = { showCommandsDialog = false },
            onRunCommand = { cmd ->
                showCommandsDialog = false
                viewModel.processCommand(cmd, hasCallPermission)
            }
        )
    }

    if (showNotesDialog) {
        NotesDialog(
            notes = notes,
            onAddNote = { text -> viewModel.addNote(text) },
            onDeleteNote = { id -> viewModel.deleteNote(id) },
            onDismiss = { showNotesDialog = false }
        )
    }

    if (showTasksDialog) {
        TasksDialog(
            tasks = tasks,
            onAddTask = { text -> viewModel.addTask(text) },
            onToggleTask = { task -> viewModel.toggleTask(task) },
            onDeleteTask = { id -> viewModel.deleteTask(id) },
            onDismiss = { showTasksDialog = false }
        )
    }

    if (showMemoryDialog) {
        MemoryBrainDialog(
            memories = memory,
            onAddMemory = { k, v -> viewModel.addMemory(k, v) },
            onDeleteMemory = { k -> viewModel.deleteMemory(k) },
            onDismiss = { showMemoryDialog = false }
        )
    }

    if (showContactsDialog) {
        ContactsDialog(
            contacts = contacts,
            onAddContact = { name, phone -> viewModel.addContact(name, phone) },
            onDeleteContact = { name -> viewModel.deleteContact(name) },
            onCallContact = { num -> viewModel.deviceController.makePhoneCall(num, hasCallPermission) },
            onWhatsAppContact = { num -> viewModel.deviceController.openWhatsAppChat(num) },
            onDismiss = { showContactsDialog = false }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            currentUserName = userName,
            currentGroqKey = groqApiKey,
            currentLanguage = preferredLanguage,
            isBackgroundActive = isBackgroundActive,
            onToggleBackgroundService = { viewModel.toggleBackgroundService(context) },
            onSaveName = { name -> viewModel.setUserName(name) },
            onSaveGroqKey = { key -> viewModel.setGroqApiKey(key) },
            onSaveLanguage = { lang -> viewModel.setLanguage(lang) },
            onDismiss = { showSettingsDialog = false }
        )
    }
}

private fun startSpeechListening(viewModel: JarvisViewModel) {
    viewModel.setVoiceState(JarvisVoiceState.LISTENING)
    viewModel.voiceManager.startListening(
        onResult = { spokenText ->
            viewModel.updateListeningAmplitude(0f)
            viewModel.processCommand(spokenText)
        },
        onError = { _ ->
            viewModel.updateListeningAmplitude(0f)
            viewModel.setVoiceState(JarvisVoiceState.IDLE)
        },
        onRmsChanged = { amp ->
            viewModel.updateListeningAmplitude(amp)
        },
        onListeningStarted = {
            viewModel.setVoiceState(JarvisVoiceState.LISTENING)
        }
    )
}
