package com.example.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.service.JarvisBackgroundService
import com.example.service.JarvisChatBridge
import com.example.service.VoiceAssistantManager
import com.example.ui.theme.JarvisCyanLight
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGoldAccent
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class VoiceTriggerActivity : ComponentActivity() {

    private var voiceManager: VoiceAssistantManager? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            triggerListening()
        } else {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Make sure background service is up
        JarvisBackgroundService.startService(this)

        val prefs = getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
        val lang = prefs.getString("preferred_language", "hi") ?: "hi"

        voiceManager = VoiceAssistantManager(this) { _ -> }
        voiceManager?.preferredLanguage = lang

        setContent {
            VoiceTriggerScreen(
                onClose = { finish() },
                onStartListening = {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        triggerListening()
                    } else {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            )
        }
    }

    private var onSpeechResult: ((String) -> Unit)? = null
    private var onSpeechError: ((String) -> Unit)? = null
    private var onAmplitudeChange: ((Float) -> Unit)? = null

    private fun triggerListening() {
        voiceManager?.startListening(
            onResult = { text ->
                onSpeechResult?.invoke(text)
                lifecycleScope.launch {
                    JarvisChatBridge.dispatchBackgroundCommand(text)
                    delay(300)
                    finish()
                }
            },
            onError = { err ->
                onSpeechError?.invoke(err)
                lifecycleScope.launch {
                    delay(1200)
                    finish()
                }
            },
            onRmsChanged = { amp ->
                onAmplitudeChange?.invoke(amp)
            },
            onListeningStarted = {}
        )
    }

    @Composable
    private fun VoiceTriggerScreen(
        onClose: () -> Unit,
        onStartListening: () -> Unit
    ) {
        var statusText by remember { mutableStateOf("JARVIS sun raha hai... Bolo!") }
        var amplitude by remember { mutableFloatStateOf(0f) }
        var isError by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            onSpeechResult = { txt ->
                statusText = "\"$txt\""
            }
            onSpeechError = { err ->
                statusText = err
                isError = true
            }
            onAmplitudeChange = { amp ->
                amplitude = amp
            }
            onStartListening()
        }

        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 1f,
            targetValue = 1.3f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "scale"
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x99050A14))
                .clickable { onClose() },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .padding(24.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(JarvisSurface)
                    .border(1.5.dp, JarvisCyanPrimary, RoundedCornerShape(24.dp))
                    .clickable(enabled = false) {}
                    .padding(24.dp)
                    .testTag("voice_trigger_dialog")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚡ JARVIS VOICE PROTOCOL",
                            color = JarvisCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Pulsing Arc Core
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .scale(pulseScale + (amplitude * 0.3f))
                                .clip(CircleShape)
                                .background(JarvisCyanPrimary.copy(alpha = 0.2f))
                        )
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .clip(CircleShape)
                                .background(JarvisSurfaceElevated)
                                .border(2.dp, JarvisCyanPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Listening",
                                tint = if (isError) JarvisGoldAccent else JarvisCyanPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = statusText,
                        color = JarvisTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Background Voice Input Active",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager?.shutdown()
    }
}
