package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JARVIS Sci-Fi Arc Reactor Palette
val JarvisBackground = Color(0xFF070B14)
val JarvisSurface = Color(0xFF0E1726)
val JarvisSurfaceElevated = Color(0xFF142036)
val JarvisSurfaceBorder = Color(0xFF1E3A5F)

val JarvisCyanPrimary = Color(0xFF00E5FF)
val JarvisCyanLight = Color(0xFF80F3FF)
val JarvisCyanDark = Color(0xFF0098A6)

val JarvisBlueGlow = Color(0xFF0091FF)
val JarvisGoldAccent = Color(0xFFFFB703)
val JarvisVioletAccent = Color(0xFF7928CA)

val JarvisGreenOnline = Color(0xFF00E676)
val JarvisRedAlert = Color(0xFFFF3366)
val JarvisAmberWarn = Color(0xFFFF9100)

val JarvisTextPrimary = Color(0xFFE8F4F8)
val JarvisTextSecondary = Color(0xFF88A0B8)
val JarvisTextMuted = Color(0xFF506880)

val JarvisTerminalBg = Color(0xCC050A12)
val JarvisGridLines = Color(0x1A00E5FF)
