package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ExternalServices
import com.example.data.api.GroqApiService
import com.example.data.db.ContactEntity
import com.example.data.db.JarvisDatabase
import com.example.data.db.MemoryEntity
import com.example.data.db.NoteEntity
import com.example.data.db.TaskEntity
import com.example.data.model.ChatMessage
import com.example.data.model.CommandGuideItem
import com.example.data.model.JarvisVoiceState
import com.example.data.model.MessageRole
import com.example.data.model.SystemStatus
import com.example.service.DeviceController
import com.example.service.MathEvaluator
import com.example.service.VoiceAssistantManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences = application.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
    private val db = JarvisDatabase.getInstance(application)
    private val dao = db.jarvisDao()

    val deviceController = DeviceController(application)
    private val externalServices = ExternalServices()
    private val groqService = GroqApiService()

    // Voice assistant manager
    val voiceManager = VoiceAssistantManager(application) { isSpeaking ->
        _systemStatus.update {
            it.copy(speechState = if (isSpeaking) JarvisVoiceState.SPEAKING else JarvisVoiceState.IDLE)
        }
    }

    // State flows
    val messages: StateFlow<List<ChatMessage>> = com.example.service.JarvisChatBridge.messages
    val isBackgroundActive: StateFlow<Boolean> = com.example.service.JarvisChatBridge.isBackgroundActive

    private val _systemStatus = MutableStateFlow(SystemStatus())
    val systemStatus: StateFlow<SystemStatus> = _systemStatus.asStateFlow()

    private val _userName = MutableStateFlow(prefs.getString("user_name", "Boss") ?: "Boss")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _groqApiKey = MutableStateFlow(
        prefs.getString("groq_api_key", GroqApiService.DEFAULT_API_KEY) ?: GroqApiService.DEFAULT_API_KEY
    )
    val groqApiKey: StateFlow<String> = _groqApiKey.asStateFlow()

    private val _preferredLanguage = MutableStateFlow(prefs.getString("preferred_language", "hi") ?: "hi")
    val preferredLanguage: StateFlow<String> = _preferredLanguage.asStateFlow()

    val notesFlow = dao.getAllNotesFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val tasksFlow = dao.getAllTasksFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val memoryFlow = dao.getAllMemoryFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val contactsFlow = dao.getAllContactsFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // History for Groq multi-turn conversation
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    init {
        // Init Groq service with saved key
        groqService.updateApiKey(_groqApiKey.value)
        voiceManager.preferredLanguage = _preferredLanguage.value

        // Seed sample contact if empty
        viewModelScope.launch(Dispatchers.IO) {
            val contacts = dao.getAllContacts()
            if (contacts.isEmpty()) {
                dao.insertContact(ContactEntity("Rohan", "9876543210"))
                dao.insertContact(ContactEntity("Emergency", "112"))
            }
        }

        // Welcome message
        if (com.example.service.JarvisChatBridge.messages.value.isEmpty()) {
            val welcomeGreeting = "Welcome ${_userName.value}. Main JARVIS hu, 37 commands ke saath online hu. Main aapki kya madad kar sakta hu?"
            addMessage(MessageRole.JARVIS, welcomeGreeting, commandTag = "ONLINE")
            speak(welcomeGreeting)
        }

        updateDeviceStatus()
    }

    fun updateDeviceStatus() {
        val (batteryPct, batteryStatus) = deviceController.getBatteryInfo()
        val volumePct = deviceController.getCurrentVolumePercent()
        val torchOn = deviceController.isTorchActive()

        _systemStatus.update {
            it.copy(
                batteryPercent = batteryPct,
                batteryStatus = batteryStatus,
                volumeLevel = volumePct,
                isTorchOn = torchOn
            )
        }
    }

    fun setUserName(name: String) {
        val clean = name.trim().ifEmpty { "Boss" }
        _userName.value = clean
        prefs.edit().putString("user_name", clean).apply()
        speak("Aapka naam $clean set kar diya hai.")
    }

    fun setGroqApiKey(apiKey: String) {
        val clean = apiKey.trim()
        _groqApiKey.value = clean
        prefs.edit().putString("groq_api_key", clean).apply()
        groqService.updateApiKey(clean)
        speak("Groq API Key update ho gayi.")
    }

    fun setLanguage(lang: String) {
        _preferredLanguage.value = lang
        prefs.edit().putString("preferred_language", lang).apply()
        voiceManager.preferredLanguage = lang
        voiceManager.setupTtsLocale()
        speak(if (lang == "hi") "Language Hindi set ho gayi" else "Language set to English")
    }

    fun setSpeechRate(rate: Float) {
        voiceManager.speechRate = rate
    }

    fun setSpeechPitch(pitch: Float) {
        voiceManager.speechPitch = pitch
    }

    fun updateListeningAmplitude(amplitude: Float) {
        _systemStatus.update { it.copy(currentListeningAmplitude = amplitude) }
    }

    fun setVoiceState(state: JarvisVoiceState) {
        _systemStatus.update { it.copy(speechState = state) }
    }

    fun toggleBackgroundService(context: Context) {
        if (com.example.service.JarvisChatBridge.isBackgroundActive.value) {
            com.example.service.JarvisBackgroundService.stopService(context)
            speak("Background protocol deactivated.")
        } else {
            com.example.service.JarvisBackgroundService.startService(context)
        }
    }

    private fun addMessage(
        role: MessageRole,
        text: String,
        commandTag: String? = null,
        isError: Boolean = false
    ) {
        val msg = ChatMessage(
            role = role,
            text = text,
            commandTag = commandTag,
            isError = isError
        )
        com.example.service.JarvisChatBridge.addMessage(msg)
    }

    fun speak(text: String) {
        voiceManager.speak(text)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    val smartCommander = com.example.service.JarvisSmartCommander(
        dao = dao,
        deviceController = deviceController,
        externalServices = externalServices,
        groqService = groqService,
        getUserName = { _userName.value },
        getPreferredLang = { _preferredLanguage.value }
    )

    // --- PROCESS COMMANDS (SMART HINDI & ENGLISH ENGINE) ---
    fun processCommand(rawInput: String, hasCallPermission: Boolean = false) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return

        addMessage(MessageRole.USER, trimmed)
        _systemStatus.update { it.copy(speechState = JarvisVoiceState.PROCESSING) }

        viewModelScope.launch {
            try {
                val result = smartCommander.execute(trimmed, hasCallPermission)
                addMessage(
                    MessageRole.JARVIS,
                    result.replyText,
                    commandTag = result.commandTag,
                    isError = result.isError
                )
                speak(result.spokenText)
            } catch (e: Exception) {
                val errorMsg = "Error aa gaya: ${e.localizedMessage ?: "Unknown error"}"
                addMessage(MessageRole.JARVIS, errorMsg, commandTag = "ERROR", isError = true)
                speak("Koi error aa gaya hai.")
            } finally {
                updateDeviceStatus()
            }
        }
    }

    // --- AI VISION ANALYZER ---
    fun analyzeImageFromStream(inputStream: InputStream) {
        viewModelScope.launch(Dispatchers.IO) {
            _systemStatus.update { it.copy(speechState = JarvisVoiceState.PROCESSING) }
            try {
                val bitmap = BitmapFactory.decodeStream(inputStream)
                val outputStream = ByteArrayOutputStream()
                // Compress to JPEG for API
                bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
                val base64 = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

                addMessage(MessageRole.USER, "[Photo sent for AI Vision analysis]")
                val result = groqService.analyzeImageBase64(base64)
                result.onSuccess { reply ->
                    addMessage(MessageRole.JARVIS, reply, commandTag = "VISION")
                    speak(reply)
                }.onFailure { err ->
                    val errorReply = "Vision analysis fail: ${err.localizedMessage}"
                    addMessage(MessageRole.JARVIS, errorReply, commandTag = "VISION", isError = true)
                    speak("Image analyze nahi ho paayi.")
                }
            } catch (e: Exception) {
                addMessage(MessageRole.JARVIS, "Photo read karne me error: ${e.message}", commandTag = "VISION", isError = true)
            } finally {
                _systemStatus.update { it.copy(speechState = JarvisVoiceState.IDLE) }
            }
        }
    }

    // Note operations
    fun addNote(content: String) = viewModelScope.launch(Dispatchers.IO) {
        if (content.isNotBlank()) dao.insertNote(NoteEntity(content = content.trim()))
    }

    fun deleteNote(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        dao.deleteNoteById(id)
    }

    // Task operations
    fun addTask(title: String) = viewModelScope.launch(Dispatchers.IO) {
        if (title.isNotBlank()) dao.insertTask(TaskEntity(title = title.trim()))
    }

    fun toggleTask(task: TaskEntity) = viewModelScope.launch(Dispatchers.IO) {
        dao.updateTask(task.copy(isCompleted = !task.isCompleted))
    }

    fun deleteTask(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        dao.deleteTaskById(id)
    }

    // Memory operations
    fun addMemory(key: String, value: String) = viewModelScope.launch(Dispatchers.IO) {
        if (key.isNotBlank() && value.isNotBlank()) dao.remember(MemoryEntity(key.trim(), value.trim()))
    }

    fun deleteMemory(key: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.deleteMemory(key)
    }

    // Contact operations
    fun addContact(name: String, phone: String) = viewModelScope.launch(Dispatchers.IO) {
        if (name.isNotBlank() && phone.isNotBlank()) dao.insertContact(ContactEntity(name.trim(), phone.trim()))
    }

    fun deleteContact(name: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.deleteContact(name)
    }

    fun clearMessages() {
        com.example.service.JarvisChatBridge.clearMessages()
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.shutdown()
    }
}
