package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JarvisVoiceState
import com.example.data.model.SystemStatus
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGoldAccent
import com.example.ui.theme.JarvisGreenOnline
import com.example.ui.theme.JarvisRedAlert
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun SystemHudBar(
    systemStatus: SystemStatus,
    userName: String,
    isBackgroundActive: Boolean,
    onToggleBackgroundService: () -> Unit,
    onToggleTorch: () -> Unit,
    onStopSpeech: () -> Unit,
    onOpenCommands: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(JarvisSurfaceElevated.copy(alpha = 0.85f))
            .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: User indicator & Battery
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(
                        when (systemStatus.speechState) {
                            JarvisVoiceState.IDLE -> JarvisGreenOnline
                            JarvisVoiceState.LISTENING -> JarvisGoldAccent
                            JarvisVoiceState.PROCESSING -> Color(0xFFBD00FF)
                            JarvisVoiceState.SPEAKING -> JarvisCyanPrimary
                        }
                    )
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = userName.uppercase(),
                color = JarvisTextPrimary,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.width(6.dp))

            // Battery
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(JarvisSurfaceBorder.copy(alpha = 0.5f))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Icon(
                    imageVector = if (systemStatus.batteryStatus.contains("Charging", ignoreCase = true)) {
                        Icons.Default.BatteryChargingFull
                    } else {
                        Icons.Default.BatteryFull
                    },
                    contentDescription = "Battery",
                    tint = if (systemStatus.batteryPercent <= 20) JarvisRedAlert else JarvisGreenOnline,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = "${systemStatus.batteryPercent}%",
                    color = JarvisTextSecondary,
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Right Action controls
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Background Chatting Power Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isBackgroundActive) JarvisCyanPrimary.copy(alpha = 0.2f)
                        else JarvisSurfaceBorder.copy(alpha = 0.3f)
                    )
                    .border(
                        1.dp,
                        if (isBackgroundActive) JarvisCyanPrimary else JarvisSurfaceBorder,
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onToggleBackgroundService() }
                    .padding(horizontal = 7.dp, vertical = 6.dp)
                    .testTag("bg_chat_toggle_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Background Chat",
                        tint = if (isBackgroundActive) JarvisCyanPrimary else JarvisTextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (isBackgroundActive) "BG ON" else "BG OFF",
                        color = if (isBackgroundActive) JarvisCyanPrimary else JarvisTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.width(5.dp))

            // Flashlight button
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (systemStatus.isTorchOn) JarvisGoldAccent.copy(alpha = 0.25f) else Color.Transparent)
                    .border(
                        1.dp,
                        if (systemStatus.isTorchOn) JarvisGoldAccent else JarvisSurfaceBorder,
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onToggleTorch() }
                    .testTag("torch_toggle_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (systemStatus.isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    contentDescription = "Toggle Torch",
                    tint = if (systemStatus.isTorchOn) JarvisGoldAccent else JarvisTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(5.dp))

            // Stop Speaking button (visible when speaking)
            if (systemStatus.speechState == JarvisVoiceState.SPEAKING) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(JarvisRedAlert.copy(alpha = 0.2f))
                        .border(1.dp, JarvisRedAlert, RoundedCornerShape(8.dp))
                        .clickable { onStopSpeech() }
                        .testTag("stop_speech_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Speech",
                        tint = JarvisRedAlert,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(5.dp))
            }

            // Commands cheat sheet button
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                    .clickable { onOpenCommands() }
                    .testTag("all_commands_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ListAlt,
                    contentDescription = "All Commands",
                    tint = JarvisCyanPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(5.dp))

            // Settings button
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                    .clickable { onOpenSettings() }
                    .testTag("settings_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = JarvisTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
