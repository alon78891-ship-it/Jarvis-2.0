# JARVIS permissions / integrations checklist

Requested capabilities may require:
- RECORD_AUDIO — voice input / wake word
- CAMERA — camera vision / photo question
- READ_CONTACTS — contact lookup
- CALL_PHONE — direct calling (otherwise dialer can be opened)
- SEND_SMS — SMS where supported
- POST_NOTIFICATIONS — JARVIS notifications
- ACCESS_NOTIFICATION_POLICY / Notification Listener — notification workflows (service-specific)
- ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION — Maps/weather/navigation
- READ_MEDIA_IMAGES / READ_MEDIA_VIDEO — media selection on supported Android versions
- READ_EXTERNAL_STORAGE — legacy Android file access where applicable
- Accessibility Service — screen understanding and UI automation
- INTERNET — AI/web/weather/integrations
- Bluetooth / nearby-device permissions — supported device integrations
- Calendar permissions — calendar read/write
- Alarm scheduling — alarms/reminders as supported by Android

Permissions must be requested only when a feature needs them. Android/POCO security and third-party app restrictions still apply.
