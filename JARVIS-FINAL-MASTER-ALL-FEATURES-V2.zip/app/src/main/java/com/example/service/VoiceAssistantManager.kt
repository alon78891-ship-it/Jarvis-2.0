package com.example.service

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceAssistantManager(
    private val context: Context,
    private val onSpeechStatusChanged: (isSpeaking: Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private val pendingSpeechQueue = mutableListOf<String>()
    private var speechRecognizer: SpeechRecognizer? = null

    var speechRate: Float = 0.94f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var speechPitch: Float = 1.0f
        set(value) {
            field = value
            tts?.setPitch(value)
        }

    var preferredLanguage: String = "hi" // "hi", "bn", "en", or "auto"
    var voiceGender: String = "female" // "male" or "female"
    var feeling: String = "neutral" // happy, excited, calm, confident, friendly, sad, serious, neutral

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true

            // Configure modern AudioAttributes for background audio clarity
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                tts?.setAudioAttributes(audioAttributes)
            }

            setupTtsLocale()
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(speechPitch)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeechStatusChanged(true)
                }

                override fun onDone(utteranceId: String?) {
                    onSpeechStatusChanged(false)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onSpeechStatusChanged(false)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    onSpeechStatusChanged(false)
                }
            })

            // Speak any queued pending speech messages (vital for background service startup)
            synchronized(pendingSpeechQueue) {
                while (pendingSpeechQueue.isNotEmpty()) {
                    val queued = pendingSpeechQueue.removeAt(0)
                    speak(queued)
                }
            }
        }
    }

    fun setupTtsLocale() {
        val ttsInstance = tts ?: return
        val targetLocale = when (preferredLanguage.lowercase()) {
            "bn", "bengali" -> Locale("bn", "IN")
            "hi", "hindi" -> Locale("hi", "IN")
            else -> Locale.US
        }

        // Android TTS engines expose voices differently by device. Pitch is used as
        // a safe cross-engine male/female preference fallback.
        val basePitch = if (voiceGender.equals("male", true)) 0.82f else 1.08f
        val feelingPitch = when (feeling.lowercase()) {
            "happy", "excited" -> 1.05f
            "calm" -> 0.94f
            "confident", "serious" -> 0.90f
            "sad" -> 0.88f
            else -> 1.0f
        }
        tts?.setPitch((basePitch * feelingPitch).coerceIn(0.6f, 1.4f))
        tts?.setSpeechRate(
            when (feeling.lowercase()) {
                "excited" -> 1.02f
                "calm", "sad" -> 0.88f
                else -> speechRate
            }
        )

        val result = ttsInstance.setLanguage(targetLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to default system language
            ttsInstance.setLanguage(Locale.getDefault())
        }
    }

    fun speak(text: String, utteranceId: String = System.currentTimeMillis().toString()) {
        val cleanText = text
            .replace("*", "")
            .replace("#", "")
            .replace("`", "")
            .replace("\"", "")
            .replace("\n", " ")
            .trim()

        if (cleanText.isBlank()) return

        if (!isTtsInitialized) {
            // Queue for immediate playback once engine binds
            synchronized(pendingSpeechQueue) {
                pendingSpeechQueue.add(cleanText)
            }
            return
        }

        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }

        tts?.stop()
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun setVoiceProfile(gender: String, emotion: String) {
        voiceGender = if (gender.equals("male", true)) "male" else "female"
        feeling = emotion.lowercase()
        if (isTtsInitialized) setupTtsLocale()
    }

    fun setLanguage(language: String) {
        preferredLanguage = when (language.lowercase()) {
            "bn", "bengali", "বাংলা" -> "bn"
            "hi", "hindi", "हिंदी" -> "hi"
            else -> "en"
        }
        if (isTtsInitialized) setupTtsLocale()
    }

    fun stopSpeaking() {
        synchronized(pendingSpeechQueue) {
            pendingSpeechQueue.clear()
        }
        tts?.stop()
        onSpeechStatusChanged(false)
    }

    fun isSpeaking(): Boolean {
        return tts?.isSpeaking == true
    }

    // --- SPEECH RECOGNITION ---
    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onRmsChanged: (Float) -> Unit,
        onListeningStarted: () -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition device par available nahi hai.")
            return
        }

        stopListening()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onListeningStarted()
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    onRmsChanged(normalized)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    val message = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Kuch suna nahi diya"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timeout"
                        SpeechRecognizer.ERROR_AUDIO -> "Audio error"
                        SpeechRecognizer.ERROR_NETWORK -> "Network issue"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission chahiye"
                        else -> "Speech recognition error ($error)"
                    }
                    onError(message)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull()?.trim() ?: ""
                    if (spokenText.isNotBlank()) {
                        onResult(spokenText)
                    } else {
                        onError("Koi aawaz detect nahi hui")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (preferredLanguage == "hi") "hi-IN" else "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            onError("Mic start karne me problem: ${e.localizedMessage}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
    }

    fun shutdown() {
        stopSpeaking()
        stopListening()
        tts?.shutdown()
        tts = null
        isTtsInitialized = false
    }
}
