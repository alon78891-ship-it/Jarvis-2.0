package com.example.service

/**
 * Master capability registry for JARVIS.
 *
 * Capabilities are exposed in one place so the UI/commander can progressively
 * enable them as Android permissions and third-party integrations become available.
 */
object JarvisFeatureRegistry {
    data class Feature(
        val id: String,
        val name: String,
        val category: String,
        val requiresPermission: Boolean = false,
        val requiresIntegration: Boolean = false
    )

    val all: List<Feature> = listOf(
        Feature("voice", "Voice commands", "Core", true),
        Feature("wake_word", "Hey JARVIS wake word", "Voice", true),
        Feature("context_memory", "Context memory", "AI"),
        Feature("natural_conversation", "Natural conversation / follow-up", "AI"),
        Feature("screen_understanding", "Screen understanding", "Vision", true),
        Feature("multi_step", "Multi-step tasks", "Agent"),
        Feature("app_automation", "App-to-app automation", "Automation", true),
        Feature("message_automation", "Message automation", "Communication", true),
        Feature("call_assistance", "Call assistance", "Communication", true),
        Feature("camera_vision", "Camera vision", "Vision", true),
        Feature("photo_question", "Photo question solver", "Education", true),
        Feature("ocr", "OCR text extraction", "Vision", true),
        Feature("document_intelligence", "PDF/document intelligence", "Documents"),
        Feature("live_web_agent", "Live web research agent", "Web", true),
        Feature("computer_control", "Browser/computer control", "Agent", true),
        Feature("smart_home", "Smart-home control", "IoT", false, true),
        Feature("proactive", "Proactive assistance", "Agent", true),
        Feature("translation", "Real-time translation", "Language", true),
        Feature("personal_voice", "Personal voice/personality", "Voice", true),
        Feature("permission_aware", "Permission-aware confirmations", "Security", true),
        Feature("life_planning", "Life planning", "Productivity"),
        Feature("autonomous_agent", "Autonomous agent mode", "Agent", true),
        Feature("personal_tutor", "Personal tutor", "Education"),
        Feature("google_search", "Google/web search", "Web", true),
        Feature("calls", "Phone calls", "Communication", true),
        Feature("sms", "SMS messaging", "Communication", true),
        Feature("apps", "App launching", "Device"),
        Feature("music", "Music controls", "Media", true),
        Feature("alarm", "Alarm", "Productivity"),
        Feature("timer", "Timer", "Productivity"),
        Feature("calendar", "Calendar/reminders", "Productivity"),
        Feature("weather", "Weather", "Information", true),
        Feature("maps", "Maps/navigation", "Navigation", true),
        Feature("notifications", "Notification actions", "Device", true),
        Feature("camera", "Camera", "Device", true),
        Feature("settings", "Phone settings", "Device"),
        Feature("calculator", "Calculator", "Utility"),
        Feature("news", "News/information", "Information", true),
        Feature("family", "Family workflows", "Communication", true),
        Feature("driving", "Driving assistance", "Navigation", true),
        Feature("third_party", "Third-party integrations", "Integration", false, true),
        Feature("files", "Files/downloads", "Device", true),
        Feature("notes", "Notes/to-do", "Productivity"),
        Feature("offline", "Offline basic commands", "Core"),
        Feature("emergency", "Emergency workflows", "Safety", true),
        Feature("scheduled", "Scheduled/recurring automation", "Automation", true),
        Feature("custom_commands", "Custom commands / modes", "Automation"),
    )
}
