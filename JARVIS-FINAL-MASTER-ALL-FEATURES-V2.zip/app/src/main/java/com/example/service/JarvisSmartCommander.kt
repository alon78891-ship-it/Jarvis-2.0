package com.example.service

import com.example.data.api.ExternalServices
import com.example.data.api.GroqApiService
import com.example.data.db.ContactEntity
import com.example.data.db.JarvisDao
import com.example.data.db.MemoryEntity
import com.example.data.db.NoteEntity
import com.example.data.db.TaskEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CommandResult(
    val replyText: String,
    val spokenText: String = replyText,
    val commandTag: String = "JARVIS",
    val isError: Boolean = false
)

class JarvisSmartCommander(
    private val dao: JarvisDao,
    private val deviceController: DeviceController,
    private val externalServices: ExternalServices,
    private val groqService: GroqApiService,
    private val getUserName: () -> String,
    private val getPreferredLang: () -> String
) {
    private val conversationMemory = mutableListOf<Pair<String, String>>()

    suspend fun execute(rawInput: String, hasCallPermission: Boolean = false): CommandResult {
        val userName = getUserName()

        // 1. Clean wake words
        var cleaned = rawInput.lowercase().trim()
        val wakeWords = listOf("hey jarvis", "he jarvis", "hi jarvis", "ok jarvis", "jarvis ji", "jarvis", "suno jarvis", "hello jarvis")
        for (w in wakeWords) {
            cleaned = cleaned.replace(w, "")
        }
        cleaned = cleaned.trim()

        if (cleaned.isEmpty()) {
            return CommandResult(
                replyText = "Haan $userName, main sun raha hu. Kahiye kya kaam hai?",
                commandTag = "ONLINE"
            )
        }

        // 2. Intent matching with natural Hindi / Hinglish understanding
        return when {
            // --- FLASHLIGHT / TORCH ---
            isTorchOnIntent(cleaned) -> {
                val ok = deviceController.setFlashlight(true)
                val reply = if (ok) "Flashlight On kar di hai $userName." else "Flashlight on nahi ho payi."
                CommandResult(reply, commandTag = "FLASH")
            }
            isTorchOffIntent(cleaned) -> {
                val ok = deviceController.setFlashlight(false)
                val reply = if (ok) "Flashlight Off kar di hai $userName." else "Flashlight off nahi ho payi."
                CommandResult(reply, commandTag = "FLASH")
            }

            // --- BATTERY ---
            isBatteryIntent(cleaned) -> {
                val (pct, status) = deviceController.getBatteryInfo()
                val reply = "Battery $pct percent hai, status: $status."
                CommandResult(reply, commandTag = "BATTERY")
            }

            // --- WEATHER ---
            isWeatherIntent(cleaned) -> {
                val city = extractCity(cleaned)
                val result = externalServices.fetchWeather(city)
                CommandResult(result, commandTag = "WEATHER")
            }

            // --- PHONE CALLS ---
            isCallIntent(cleaned) -> {
                val target = extractCallTarget(cleaned)
                handleCall(target, hasCallPermission, userName)
            }

            // --- WHATSAPP ---
            cleaned.contains("whatsapp") -> {
                handleWhatsApp(cleaned)
            }

            // --- ALARM ---
            isAlarmIntent(cleaned) -> {
                handleAlarm(cleaned)
            }

            // --- NOTES ---
            isNoteAddIntent(cleaned) -> {
                val noteText = extractNoteText(cleaned)
                if (noteText.isNotBlank()) {
                    dao.insertNote(NoteEntity(content = noteText))
                    CommandResult("Note save kar diya: '$noteText'", commandTag = "NOTE")
                } else {
                    CommandResult("Note me kya likhna hai bataiye.", commandTag = "NOTE")
                }
            }
            isNoteShowIntent(cleaned) -> {
                val notes = dao.getAllNotes()
                if (notes.isEmpty()) {
                    CommandResult("Aapke paas koi saved notes nahi hain.", commandTag = "NOTE")
                } else {
                    val summary = notes.mapIndexed { i, n -> "${i + 1}. ${n.content}" }.joinToString("\n")
                    val speech = "Aapke ${notes.size} notes hain: " + notes.take(3).joinToString(", ") { it.content }
                    CommandResult("Notes:\n$summary", spokenText = speech, commandTag = "NOTE")
                }
            }

            // --- TASKS / TO-DO ---
            isTaskAddIntent(cleaned) -> {
                val taskTitle = extractTaskTitle(cleaned)
                if (taskTitle.isNotBlank()) {
                    dao.insertTask(TaskEntity(title = taskTitle))
                    CommandResult("Task add kar diya: '$taskTitle'", commandTag = "TASK")
                } else {
                    CommandResult("Task ka naam bataiye.", commandTag = "TASK")
                }
            }
            isTaskShowIntent(cleaned) -> {
                val tasks = dao.getAllTasks()
                if (tasks.isEmpty()) {
                    CommandResult("Aapki to-do list khali hai.", commandTag = "TASK")
                } else {
                    val summary = tasks.mapIndexed { i, t -> "${i + 1}. [${if (t.isCompleted) "✓" else " "}] ${t.title}" }.joinToString("\n")
                    val speech = "Aapke ${tasks.size} tasks hain: " + tasks.take(3).joinToString(", ") { it.title }
                    CommandResult("Tasks:\n$summary", spokenText = speech, commandTag = "TASK")
                }
            }

            // --- MEMORY / BRAIN (REMEMBER & RECALL) ---
            isRememberIntent(cleaned) -> {
                handleRemember(cleaned)
            }
            isRecallIntent(cleaned) -> {
                handleRecall(cleaned, rawInput, userName)
            }

            // --- CALCULATION ---
            isCalculationIntent(cleaned) -> {
                handleCalculation(cleaned)
            }

            // --- TIME & DATE ---
            listOf("time", "samay", "kitna baj raha", "kitne baje").any { cleaned.contains(it) } -> {
                val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                CommandResult("Abhi samay $timeStr hua hai.", commandTag = "TIME")
            }
            listOf("date", "aaj ki date", "tarikh", "aaj ka din").any { cleaned.contains(it) } -> {
                val dateStr = SimpleDateFormat("dd MMMM yyyy, EEEE", Locale.getDefault()).format(Date())
                CommandResult("Aaj ki date hai $dateStr.", commandTag = "DATE")
            }

            // --- MUSIC & YOUTUBE ---
            isMusicIntent(cleaned) -> {
                val song = extractSongName(cleaned)
                deviceController.playSongOnYouTube(song)
                CommandResult("YouTube par '$song' search kar raha hu.", commandTag = "YOUTUBE")
            }

            // --- GOOGLE SEARCH ---
            cleaned.startsWith("google ") || cleaned.contains("google search") -> {
                val query = cleaned.removePrefix("google search").removePrefix("google").trim()
                deviceController.openGoogleSearch(query)
                CommandResult("Google par '$query' search kar raha hu.", commandTag = "SEARCH")
            }

            // --- WIKIPEDIA ---
            cleaned.startsWith("wiki ") || cleaned.startsWith("wikipedia ") || cleaned.endsWith("kon hai") -> {
                val q = cleaned.removePrefix("wikipedia").removePrefix("wiki").removeSuffix("kon hai").trim()
                val result = externalServices.fetchWikiSummary(q)
                CommandResult(result, commandTag = "WIKI")
            }

            // --- TRANSLATE ---
            cleaned.startsWith("translate ") || cleaned.contains("ka matlab kya hai") -> {
                val textToTranslate = cleaned.removePrefix("translate ").removeSuffix("ka matlab kya hai").trim()
                val res = externalServices.translateText(textToTranslate)
                CommandResult("Translation: $res", spokenText = res, commandTag = "TRANSLATE")
            }

            // --- VOLUME CONTROLS ---
            listOf("volume up", "awaz badhao", "sound badhao").any { cleaned.contains(it) } -> {
                val vol = deviceController.adjustVolume(up = true)
                CommandResult("Volume badha diya ($vol%).", commandTag = "VOLUME")
            }
            listOf("volume down", "awaz kam karo", "sound kam karo").any { cleaned.contains(it) } -> {
                val vol = deviceController.adjustVolume(up = false)
                CommandResult("Volume kam kar diya ($vol%).", commandTag = "VOLUME")
            }

            // --- CAMERA / PERMISSIONS / VISION ---
            listOf("camera kholo", "open camera", "camera open", "camera chalu").any { cleaned.contains(it) } -> {
                val ok = deviceController.openCamera()
                CommandResult(if (ok) "Camera open kar diya hai." else "Camera open nahi ho paya.", commandTag = "CAMERA")
            }
            listOf("permission", "permissions", "permission kholo", "permissions kholo").any { cleaned.contains(it) } -> {
                deviceController.openAppPermissions()
                CommandResult("JARVIS app permissions screen khol raha hu.", commandTag = "PERMISSION")
            }
            listOf("accessibility permission", "accessibility kholo", "screen control permission").any { cleaned.contains(it) } -> {
                deviceController.openAccessibilitySettings()
                CommandResult("Accessibility settings khol raha hu. Wahan JARVIS ko Allow kijiye.", commandTag = "PERMISSION")
            }
            listOf("screen lock settings", "lock settings").any { cleaned.contains(it) } -> {
                deviceController.openScreenLockSettings()
                CommandResult("Security settings khol raha hu.", commandTag = "SECURITY")
            }
            listOf("vision on", "jarvis vision on", "camera always on").any { cleaned.contains(it) } -> {
                CommandResult("JARVIS Vision ON command ready hai. Camera ko background me continuously chalane ke liye Android ka camera foreground-service permission aur user consent zaroori hai.", commandTag = "VISION")
            }
            listOf("vision off", "jarvis vision off", "camera always off").any { cleaned.contains(it) } -> {
                CommandResult("JARVIS Vision OFF.", commandTag = "VISION")
            }

            // --- IMAGE GENERATOR ---
            (cleaned.startsWith("generate image") || cleaned.startsWith("image banao") || cleaned.startsWith("image generate")) -> {
                val prompt = cleaned.removePrefix("generate image").removePrefix("image banao").removePrefix("image generate").trim()
                val ok = deviceController.openImageGenerator(prompt)
                CommandResult(if (ok) "Image generator open kar diya hai." else "Image generator open nahi ho paya.", commandTag = "IMAGE")
            }

            // --- VOICE PROFILE / FEELING ---
            listOf("male voice", "female voice", "male awaaz", "female awaaz").any { cleaned.contains(it) } -> {
                val gender = if (cleaned.contains("male")) "male" else "female"
                CommandResult("Voice preference $gender set karne ke liye configuration me Voice Profile use kijiye.", commandTag = "VOICE")
            }
            listOf("happy feeling", "excited feeling", "calm feeling", "confident feeling", "friendly feeling", "sad feeling", "serious feeling", "neutral feeling").any { cleaned.contains(it) } -> {
                val emotion = listOf("happy","excited","calm","confident","friendly","sad","serious","neutral").firstOrNull { cleaned.contains(it) } ?: "neutral"
                CommandResult("JARVIS feeling $emotion select karne ke liye ready hai.", commandTag = "FEELING")
            }

            // --- OFFLINE BRAIN ---
            listOf("offline mode", "offline brain", "offline brain on").any { cleaned.contains(it) } -> {
                CommandResult("Offline Brain active: local commands, calculator, torch, volume, apps, contacts aur alarms internet ke bina chal sakte hain.", commandTag = "OFFLINE")
            }

            // --- MEDIA ACCESSIBILITY CONTROL ---
            listOf("video rok do", "video pause", "pause video").any { cleaned.contains(it) } -> {
                val ok = deviceController.controlScreen("play_pause")
                CommandResult(if (ok) "Video pause/play control bhej diya." else "Accessibility permission enable kijiye, phir main video control karunga.", commandTag = "MEDIA")
            }
            listOf("video chalao", "play video").any { cleaned.contains(it) } -> {
                val ok = deviceController.controlScreen("play_pause")
                CommandResult(if (ok) "Video play control bhej diya." else "Accessibility permission enable kijiye.", commandTag = "MEDIA")
            }
            listOf("scroll up", "upar scroll").any { cleaned.contains(it) } -> {
                val ok = deviceController.controlScreen("scroll_up")
                CommandResult(if (ok) "Upar scroll kar diya." else "Accessibility permission enable kijiye.", commandTag = "MEDIA")
            }
            listOf("scroll down", "neeche scroll").any { cleaned.contains(it) } -> {
                val ok = deviceController.controlScreen("scroll_down")
                CommandResult(if (ok) "Neeche scroll kar diya." else "Accessibility permission enable kijiye.", commandTag = "MEDIA")
            }
            listOf("next video", "agla video").any { cleaned.contains(it) } -> {
                val ok = deviceController.controlScreen("next")
                CommandResult(if (ok) "Next media command bhej diya." else "Accessibility permission enable kijiye.", commandTag = "MEDIA")
            }

            // --- APPS OPENER ---
            isOpenAppIntent(cleaned) -> {
                val app = extractAppName(cleaned)
                val ok = deviceController.openApp(app)
                if (ok) CommandResult("$app khol diya hai.", commandTag = "APP")
                else CommandResult("$app open nahi ho paya.", commandTag = "APP", isError = true)
            }

            // --- CLIPBOARD ---
            cleaned.startsWith("type ") || cleaned.startsWith("copy ") -> {
                val text = cleaned.removePrefix("type ").removePrefix("copy ").trim()
                deviceController.copyToClipboard(text)
                CommandResult("Clipboard me copy kar diya: '$text'", spokenText = "Clipboard me copy ho gaya.", commandTag = "CLIPBOARD")
            }

            // --- HELP / IDENTITY ---
            listOf("tum kon ho", "who are you", "what can you do", "kya kar sakte ho", "help", "commands").any { cleaned.contains(it) } -> {
                val reply = "Main JARVIS hu — aapka high-tech AI Assistant. Main voice calls, WhatsApp, mausam, alarm, flashlight, notes, tasks, memory, math calculation aur smart conversation sab sambhal sakta hu."
                CommandResult(reply, commandTag = "HELP")
            }

            // --- DEFAULT: GROQ LLAMA 3.1 AI CONVERSATION ---
            else -> {
                askGroq(rawInput, userName)
            }
        }
    }

    private suspend fun askGroq(userPrompt: String, userName: String): CommandResult {
        conversationMemory.add(Pair("user", userPrompt))
        if (conversationMemory.size > 10) {
            val trimmed = conversationMemory.takeLast(8).toMutableList()
            conversationMemory.clear()
            conversationMemory.addAll(trimmed)
        }

        val result = groqService.chatCompletion(conversationMemory, userName = userName)
        return result.fold(
            onSuccess = { reply ->
                conversationMemory.add(Pair("assistant", reply))
                CommandResult(reply, commandTag = "AI")
            },
            onFailure = { error ->
                val detail = error.message.orEmpty()
                val fallback = when {
                    detail.contains("401") -> "Groq API key invalid hai. Settings me nayi key save kijiye."
                    detail.contains("403") -> "Groq API access blocked hai. Groq project/model permissions check kijiye."
                    detail.contains("429") -> "Groq rate limit hit ho gayi hai. Thodi der baad dobara try kijiye."
                    detail.contains("400") -> "Groq request reject hui. Model/request configuration check kar raha hu."
                    detail.contains("missing", ignoreCase = true) -> "Groq API key set nahi hai. Settings me key save kijiye."
                    detail.contains("timeout", ignoreCase = true) || detail.contains("Unable to resolve host", ignoreCase = true) -> "Groq server tak network connection nahi ban paaya. Internet check kijiye."
                    else -> "AI service se response nahi mila. Network ya Groq configuration issue hai."
                }
                CommandResult(fallback, commandTag = "AI", isError = true)
            }
        )
    }

    // --- INTENT HELPERS ---
    private fun isTorchOnIntent(c: String): Boolean =
        listOf("flash on", "torch on", "torch jalao", "light on", "batti jalao", "flashlight on").any { c.contains(it) }

    private fun isTorchOffIntent(c: String): Boolean =
        listOf("flash off", "torch off", "torch band karo", "light off", "batti band karo", "flashlight off").any { c.contains(it) }

    private fun isBatteryIntent(c: String): Boolean =
        listOf("battery", "charge kitna", "battery percentage", "charging status", "battery status").any { c.contains(it) }

    private fun isWeatherIntent(c: String): Boolean =
        listOf("weather", "mausam", "barish", "tapman", "temperature").any { c.contains(it) }

    private fun extractCity(c: String): String {
        val words = c.split(" ")
        val ignore = setOf("weather", "in", "ka", "me", "kaisa", "hai", "batao", "aaj", "report", "mausam", "kya")
        val candidate = words.filterNot { ignore.contains(it) }.joinToString(" ").trim()
        return if (candidate.isNotBlank()) candidate else "Dulalgram"
    }

    private fun isCallIntent(c: String): Boolean =
        c.startsWith("call ") || c.contains("ko call") || c.contains("phone lagao") || c.contains("dial ")

    private fun extractCallTarget(c: String): String {
        return c.replace("ko call karo", "")
            .replace("ko call lagao", "")
            .replace("ko phone lagao", "")
            .replace("phone lagao", "")
            .replace("call karo", "")
            .replace("call", "")
            .replace("dial", "")
            .trim()
    }

    private suspend fun handleCall(target: String, hasCallPermission: Boolean, userName: String): CommandResult {
        if (target.isBlank()) return CommandResult("Kise call lagana hai?", commandTag = "CALL")
        val isDigits = target.replace(" ", "").replace("-", "").all { it.isDigit() }
        if (isDigits) {
            val ok = deviceController.makePhoneCall(target, hasCallPermission)
            return CommandResult(if (ok) "$target ko call laga raha hu." else "Call lagane me error aaya.", commandTag = "CALL")
        }
        val number = dao.getPhoneNumberByName(target)
        if (number != null) {
            val ok = deviceController.makePhoneCall(number, hasCallPermission)
            return CommandResult(if (ok) "$target ko call laga raha hu." else "Call lagane me error aaya.", commandTag = "CALL")
        }
        return CommandResult("Contact '$target' nahi mila. Aap 'add contact $target <number>' bol sakte hain.", commandTag = "CALL")
    }

    private suspend fun handleWhatsApp(c: String): CommandResult {
        if (c.contains(" to ")) {
            val parts = c.removePrefix("whatsapp ").split(" to ", limit = 2)
            val msg = parts[0].trim()
            val target = parts[1].trim()
            return sendWhatsAppTo(target, msg)
        }

        // Hindi/Hinglish: "whatsapp Rohan ko hello bhejo"
        val afterWhatsApp = c.removePrefix("whatsapp ").trim()
        if (afterWhatsApp.contains(" ko ")) {
            val parts = afterWhatsApp.split(" ko ", limit = 2)
            val target = parts[0].trim()
            val msg = parts[1]
                .removeSuffix(" bhejo")
                .removeSuffix(" bhej do")
                .removeSuffix(" send karo")
                .removeSuffix(" send")
                .trim()
            if (target.isNotBlank() && msg.isNotBlank()) {
                return sendWhatsAppTo(target, msg)
            }
        }

        // Natural form: "Rohan ko WhatsApp pe hello bhejo"
        if (c.contains(" ko whatsapp ")) {
            val parts = c.split(" ko whatsapp ", limit = 2)
            val target = parts[0].trim()
            val msg = parts[1]
                .removePrefix("par ")
                .removePrefix("pe ")
                .removeSuffix(" bhejo")
                .removeSuffix(" bhej do")
                .removeSuffix(" send karo")
                .removeSuffix(" send")
                .trim()
            if (target.isNotBlank() && msg.isNotBlank()) {
                return sendWhatsAppTo(target, msg)
            }
        }

        val person = c.removePrefix("open whatsapp").removePrefix("whatsapp").replace("ko", "").replace("pe", "").trim()
        if (person.isNotBlank()) {
            val num = dao.getPhoneNumberByName(person) ?: person
            deviceController.openWhatsAppChat(num)
            return CommandResult("$person ka WhatsApp khol diya.", commandTag = "WHATSAPP")
        }
        deviceController.openApp("whatsapp")
        return CommandResult("WhatsApp khol diya.", commandTag = "WHATSAPP")
    }

    private suspend fun sendWhatsAppTo(target: String, message: String): CommandResult {
        val contactNum = dao.getPhoneNumberByName(target) ?: target
        val permissionReady = deviceController.isWhatsAppAutomationEnabled()
        deviceController.sendWhatsApp(contactNum, message)
        return if (permissionReady) {
            CommandResult("WhatsApp khol kar message automatically send kar raha hu.", commandTag = "WHATSAPP")
        } else {
            CommandResult(
                "Pehli baar JARVIS Accessibility permission Allow karein. Allow karte hi WhatsApp khulega aur message automatically send hoga.",
                commandTag = "WHATSAPP"
            )
        }
    }

    private fun isAlarmIntent(c: String): Boolean =
        c.startsWith("alarm ") || c.contains("alarm laga") || c.contains("baje ka alarm")

    private fun handleAlarm(c: String): CommandResult {
        val digits = c.filter { it.isDigit() || it == ':' }
        val parts = digits.split(":")
        if (parts.size >= 2 && parts[0].toIntOrNull() != null && parts[1].toIntOrNull() != null) {
            val h = parts[0].toInt()
            val m = parts[1].toInt()
            val ok = deviceController.setAlarm(h, m, "JARVIS Alarm")
            return CommandResult(if (ok) "Alarm $digits ke liye set kar diya." else "Alarm set nahi ho saka.", commandTag = "ALARM")
        }
        return CommandResult("Alarm ke liye samay bataiye, jaise: alarm 07:30", commandTag = "ALARM")
    }

    private fun isNoteAddIntent(c: String): Boolean =
        c.startsWith("note ") || c.contains("note likho") || c.contains("note banao")

    private fun extractNoteText(c: String): String =
        c.removePrefix("note likho").removePrefix("note banao").removePrefix("note").trim()

    private fun isNoteShowIntent(c: String): Boolean =
        listOf("show notes", "notes dikhao", "notes padho", "read notes", "my notes").any { c.contains(it) }

    private fun isTaskAddIntent(c: String): Boolean =
        c.startsWith("add task ") || c.contains("task banao") || c.contains("task add karo")

    private fun extractTaskTitle(c: String): String =
        c.removePrefix("add task").removePrefix("task banao").removePrefix("task add karo").removePrefix("task").trim()

    private fun isTaskShowIntent(c: String): Boolean =
        listOf("show tasks", "tasks dikhao", "my tasks", "todo", "kya task baki").any { c.contains(it) }

    private fun isRememberIntent(c: String): Boolean =
        c.startsWith("remember ") || c.contains("yaad rakhna") || c.contains("yaad rakho")

    private suspend fun handleRemember(c: String): CommandResult {
        val clean = c.removePrefix("remember").removePrefix("yaad rakhna").removePrefix("yaad rakho").trim()
        if (clean.contains("=")) {
            val parts = clean.split("=", limit = 2)
            val k = parts[0].trim()
            val v = parts[1].trim()
            dao.remember(MemoryEntity(key = k, value = v))
            return CommandResult("Yaad rakh liya: '$k' = '$v'", commandTag = "BRAIN")
        } else if (clean.contains("hai")) {
            val parts = clean.split("hai", limit = 2)
            val k = parts[0].trim()
            dao.remember(MemoryEntity(key = k, value = clean))
            return CommandResult("Yaad rakh liya: '$clean'", commandTag = "BRAIN")
        }
        return CommandResult("Format use karein: remember password = 12345", commandTag = "BRAIN")
    }

    private fun isRecallIntent(c: String): Boolean =
        c.startsWith("what is ") || c.contains("kya hai") || c.contains("kya tha")

    private suspend fun handleRecall(c: String, rawInput: String, userName: String): CommandResult {
        val key = c.removePrefix("what is").replace("kya hai", "").replace("kya tha", "").replace("mera", "").trim()
        val mem = dao.getMemoryValue(key)
        if (mem != null) {
            return CommandResult("$key hai: $mem", commandTag = "BRAIN")
        }
        return askGroq(rawInput, userName)
    }

    private fun isCalculationIntent(c: String): Boolean =
        c.startsWith("calculate ") || c.startsWith("calc ") ||
        listOf("plus", "minus", "into", "divided by", "*", "+", "/", "%").any { c.contains(it) && c.any { ch -> ch.isDigit() } }

    private fun handleCalculation(c: String): CommandResult {
        val sanitized = c.removePrefix("calculate").removePrefix("calc")
            .replace("into", "*")
            .replace("multiplied by", "*")
            .replace("plus", "+")
            .replace("minus", "-")
            .replace("divided by", "/")
            .trim()
        return try {
            val res = MathEvaluator.evaluate(sanitized)
            val formatted = if (res % 1.0 == 0.0) res.toLong().toString() else String.format(Locale.US, "%.3f", res)
            CommandResult("Answer: $formatted", spokenText = "Answer hai $formatted", commandTag = "CALC")
        } catch (e: Exception) {
            CommandResult("Calculation error.", isError = true, commandTag = "CALC")
        }
    }

    private fun isMusicIntent(c: String): Boolean =
        c.startsWith("play song") || c.startsWith("play ") || c.contains("gaana bajao") || c.contains("chalao youtube")

    private fun extractSongName(c: String): String =
        c.removePrefix("play song").removePrefix("play").replace("gaana bajao", "").replace("chalao youtube pe", "").trim()

    private fun isOpenAppIntent(c: String): Boolean =
        listOf("camera", "gallery", "whatsapp", "instagram", "youtube", "chrome", "google", "calculator", "settings", "telegram", "facebook", "spotify").any { c.contains(it) }

    private fun extractAppName(c: String): String {
        return listOf("camera", "gallery", "whatsapp", "instagram", "youtube", "chrome", "google", "calculator", "settings", "telegram", "facebook", "spotify")
            .firstOrNull { c.contains(it) } ?: "settings"
    }
}
