# J.A.R.V.I.S. Android

Android Kotlin starter project containing:

- JARVIS command router
- Hindi/Hinglish Text-to-Speech
- Groq cloud chat bridge
- Hardware diagnostics
- Flashlight control
- Brightness control
- Media key control
- Wi-Fi information/security heuristic
- Installed-app keyword security scan
- VPN/network status audit
- Accessibility service registration
- Foreground service

## Important

1. The Groq API key is intentionally blank in `app/build.gradle.kts`.
2. Do not publish a real Groq API key inside an APK. For production use a backend.
3. Accessibility, overlay, and write-settings access must be manually enabled by the user.
4. Wi-Fi scan/details can require location-related permission/settings depending on Android version.
5. The Wi-Fi radar is a heuristic information scanner. It does not prove that an access point is rogue, malicious, or being used for packet interception.
6. Android does not provide unrestricted root/system control to a normal application.

## Build

Open this folder in Android Studio, allow Gradle sync, then build the debug APK.

For development-only Groq testing, set the `GROQ_API_KEY` BuildConfig field in `app/build.gradle.kts`.

Recommended production architecture:

Android JARVIS -> your backend -> Groq API

This keeps the secret API key off the client APK.

## Wi-Fi Audit Skill
Added defensive Wi-Fi auditing for nearby networks: SSID, BSSID, channel, RSSI and basic advertised security flags. It intentionally does not perform deauthentication, credential capture, password cracking, or automatic targeting.
