plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // IMPORTANT: Replace this for development only.
        // For production, use a backend so the API secret is not shipped in the APK.
        buildConfigField("String", "GROQ_API_KEY", "\"\"")
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
