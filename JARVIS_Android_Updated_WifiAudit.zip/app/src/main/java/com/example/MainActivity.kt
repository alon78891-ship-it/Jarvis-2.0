package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.appcompat.app.AppCompatActivity
import com.example.service.JarvisAccessibilityService
import com.example.service.JarvisBackgroundService

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkAndRequestPrivileges()
    }

    override fun onResume() {
        super.onResume()
        checkAndRequestPrivileges()
    }

    private fun checkAndRequestPrivileges() {
        if (!Settings.System.canWrite(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
            return
        }

        if (!isAccessibilityServiceEnabled(
                this,
                JarvisAccessibilityService::class.java
            )
        ) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        startJarvisService()
    }

    private fun startJarvisService() {
        val intent = Intent(this, JarvisBackgroundService::class.java)
        startForegroundService(intent)
    }

    private fun isAccessibilityServiceEnabled(
        context: Context,
        service: Class<*>
    ): Boolean {
        val expected = "${context.packageName}/${service.name}"
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)

        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) {
                return true
            }
        }
        return false
    }
}
