package com.example.service

import android.content.Context
import android.content.Intent
import android.net.Uri

class JarvisSmartCommander(private val context: Context) {

    private val deviceController = DeviceController(context)
    private val securityMatrix = JarvisSecurityMatrix(context)
    private val mathEvaluator = MathEvaluator()
    private val wifiRadar = JarvisWifiRadar(context)
    private val chatBridge = JarvisChatBridge(context)

    fun execute(voiceInput: String) {
        val normalizedInput = voiceInput.trim().lowercase()

        when {
            normalizedInput.contains("system diagnostic") ||
            normalizedInput.contains("hardware status") ||
            normalizedInput.contains("phone condition") -> {
                deviceController.triggerPulseFeedback()
                chatBridge.speak(
                    deviceController.runFullHardwareDiagnostics()
                )
            }

            normalizedInput.contains("calculate") ||
            normalizedInput.startsWith("solve ") ||
            normalizedInput.contains("hisaab karo") -> {
                deviceController.triggerPulseFeedback()

                val expression = normalizedInput
                    .replaceFirst("calculate", "")
                    .replaceFirst("hisaab karo", "")
                    .replaceFirst("solve", "")
                    .trim()

                chatBridge.speak(
                    mathEvaluator.evaluateStringExpression(expression)
                )
            }

            normalizedInput.contains("scan apps") ||
            normalizedInput.contains("threat radar") ||
            normalizedInput.contains("virus check") -> {
                deviceController.triggerPulseFeedback()
                chatBridge.speak(
                    securityMatrix.scanInstalledPackagesForThreats()
                )
            }

            normalizedInput.contains("wifi audit") ||
            normalizedInput.contains("wifi security") ||
            normalizedInput.contains("check wifi") ||
            normalizedInput.contains("check connection security") -> {
                deviceController.triggerPulseFeedback()
                chatBridge.speak(
                    wifiRadar.scanCurrentWifiSecurity()
                )
            }

            normalizedInput.contains("scan networks") ||
            normalizedInput.contains("wifi scan") ||
            normalizedInput.contains("nearby wifi") ||
            normalizedInput.contains("network radar") ||
            normalizedInput.contains("wifi audit scan") -> {
                deviceController.triggerPulseFeedback()
                chatBridge.speak(
                    wifiRadar.scanForVulnerablePerimeters()
                )
            }

            normalizedInput.contains("torch on") ||
            normalizedInput.contains("flashlight on") -> {
                deviceController.toggleFlashlight(true)
                chatBridge.speak("Flashlight activated, Sir.")
            }

            normalizedInput.contains("torch off") ||
            normalizedInput.contains("flashlight off") -> {
                deviceController.toggleFlashlight(false)
                chatBridge.speak("Flashlight deactivated, Sir.")
            }

            normalizedInput.contains("brightness full") -> {
                deviceController.adjustBrightness(255)
                chatBridge.speak("Display brightness set to maximum, Sir.")
            }

            normalizedInput.contains("brightness dim") -> {
                deviceController.adjustBrightness(30)
                chatBridge.speak("Display brightness reduced, Sir.")
            }

            normalizedInput.contains("play music") -> {
                deviceController.injectMediaKey(
                    android.view.KeyEvent.KEYCODE_MEDIA_PLAY
                )
                chatBridge.speak("Playback command sent, Sir.")
            }

            normalizedInput.contains("pause music") -> {
                deviceController.injectMediaKey(
                    android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
                )
                chatBridge.speak("Playback paused, Sir.")
            }

            normalizedInput.contains("security audit") ||
            normalizedInput.contains("system security") ||
            normalizedInput.contains("firewall audit") -> {
                deviceController.triggerPulseFeedback()
                chatBridge.speak(
                    securityMatrix.runSystemAudit()
                )
            }

            normalizedInput.contains("youtube") -> {
                openUrl("https://www.youtube.com")
                chatBridge.speak("Opening YouTube, Sir.")
            }

            normalizedInput.contains("whatsapp") -> {
                openPackage("com.whatsapp")
                chatBridge.speak("Opening WhatsApp, Sir.")
            }

            normalizedInput.contains("settings") -> {
                context.startActivity(
                    Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
                chatBridge.speak("Opening system settings, Sir.")
            }

            else -> {
                chatBridge.sendToGroqCloud(voiceInput)
            }
        }
    }

    private fun openPackage(packageName: String) {
        try {
            val intent = context.packageManager
                .getLaunchIntentForPackage(packageName)

            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                chatBridge.speak("Sir, requested application installed nahi hai.")
            }
        } catch (_: Exception) {
            chatBridge.speak("Sir, application open nahi ho saka.")
        }
    }

    private fun openUrl(url: String) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (_: Exception) {
            chatBridge.speak("Sir, browser open nahi ho saka.")
        }
    }

    fun destroy() {
        chatBridge.destroy()
    }
}
