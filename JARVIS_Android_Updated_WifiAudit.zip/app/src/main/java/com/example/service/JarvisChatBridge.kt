package com.example.service

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.BuildConfig
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

class JarvisChatBridge(
    context: Context
) : TextToSpeech.OnInitListener {

    private var ttsEngine: TextToSpeech? =
        TextToSpeech(context.applicationContext, this)

    private var isInitialized = false

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val endpointUrl =
        "https://api.groq.com/openai/v1/chat/completions"

    private val model =
        "llama-3.1-8b-instant"

    private val groqApiKey: String
        get() = BuildConfig.GROQ_API_KEY

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = ttsEngine?.setLanguage(Locale("hi", "IN"))

            if (
                result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                ttsEngine?.setLanguage(Locale.US)
            }

            isInitialized = true
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) return

        if (isInitialized) {
            ttsEngine?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "JarvisEngine"
            )
        }

        Log.d("JARVIS_SPEECH", text)
    }

    fun sendToGroqCloud(userInput: String) {
        if (userInput.isBlank()) {
            speak("Sir, mujhe koi question receive nahi hua.")
            return
        }

        if (groqApiKey.isBlank()) {
            speak("Sir, Groq API configuration complete nahi hai.")
            return
        }

        val messages = JSONArray().apply {
            put(JSONObject().apply {
                put("role", "system")
                put(
                    "content",
                    "Aap JARVIS hain, ek intelligent personal Android assistant. " +
                        "Natural Hindi, Hinglish ya English mein concise aur useful jawab dein. " +
                        "Professional aur helpful tone rakhein."
                )
            })

            put(JSONObject().apply {
                put("role", "user")
                put("content", userInput)
            })
        }

        val payload = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", 0.7)
            put("max_completion_tokens", 512)
        }

        val body = payload.toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(endpointUrl)
            .addHeader("Authorization", "Bearer $groqApiKey")
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()

        speak("Cloud intelligence core activate kar raha hoon, Sir.")

        httpClient.newCall(request).enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                Log.e("JARVIS_GROQ", "Groq connection failed", e)
                speak("Sir, cloud connection establish nahi ho paya.")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val bodyText = response.body?.string()

                    if (!response.isSuccessful) {
                        Log.e(
                            "JARVIS_GROQ",
                            "HTTP ${response.code}: $bodyText"
                        )

                        speak(
                            when (response.code) {
                                401 -> "Sir, Groq authorization key invalid hai."
                                429 -> "Sir, cloud request limit temporarily reached hai."
                                else -> "Sir, Groq cloud ne request reject kar di."
                            }
                        )
                        return
                    }

                    try {
                        val json = JSONObject(bodyText ?: "")
                        val answer = json
                            .getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                            .trim()

                        speak(
                            answer.ifBlank {
                                "Sir, cloud se empty response receive hua."
                            }
                        )
                    } catch (e: Exception) {
                        Log.e("JARVIS_GROQ", "Response parsing failed", e)
                        speak("Sir, cloud response process karne mein problem hui.")
                    }
                }
            }
        })
    }

    fun destroy() {
        try {
            ttsEngine?.stop()
            ttsEngine?.shutdown()
            ttsEngine = null
            isInitialized = false
            httpClient.dispatcher.executorService.shutdown()
            httpClient.connectionPool.evictAll()
        } catch (e: Exception) {
            Log.e("JARVIS_CHAT", "Shutdown error", e)
        }
    }
}
