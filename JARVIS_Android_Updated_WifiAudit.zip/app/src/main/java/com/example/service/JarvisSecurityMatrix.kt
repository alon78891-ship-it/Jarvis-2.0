package com.example.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import java.net.NetworkInterface
import java.util.Collections

class JarvisSecurityMatrix(private val context: Context) {

    fun runSystemAudit(): String {
        val vpn = checkVpnStatus()
        val ip = getLocalIpAddress()

        return buildString {
            append("Sir, system security audit complete. ")
            if (vpn) append("VPN connection detected. ")
            else append("No VPN connection detected. ")
            append("Local network address $ip. ")
            append("Android network security information successfully checked.")
        }
    }

    fun getVpnStatusReport(): String =
        if (checkVpnStatus()) {
            "Sir, VPN connection currently active hai."
        } else {
            "Sir, currently koi VPN connection detected nahi hua."
        }

    fun getNetworkStatusReport(): String =
        "Sir, current local network address ${getLocalIpAddress()} hai."

    fun scanInstalledPackagesForThreats(): String {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(0)
        var flags = 0

        for (pkg in packages) {
            val label = pkg.applicationInfo?.loadLabel(pm)?.toString()?.lowercase() ?: ""
            val packageName = pkg.packageName.lowercase()

            if (
                label.contains("spy") ||
                label.contains("keylogger") ||
                label.contains("trojan") ||
                label.contains("hack") ||
                packageName.contains("keylogger") ||
                packageName.contains("spyware")
            ) {
                flags++
            }
        }

        return if (flags > 0) {
            "Sir, $flags installed app(s) matched simple security keywords. " +
                "Ye heuristic flags hain, confirmed malware detection nahi."
        } else {
            "Sir, installed-app keyword sweep mein koi obvious security keyword flag nahi mila."
        }
    }

    private fun checkVpnStatus(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        } catch (e: Exception) {
            Log.e("JARVIS_SECURITY", "VPN check failed", e)
            false
        }
    }

    private fun getLocalIpAddress(): String {
        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())

            for (networkInterface in interfaces) {
                val addresses = Collections.list(networkInterface.inetAddresses)

                for (address in addresses) {
                    if (!address.isLoopbackAddress) {
                        val ip = address.hostAddress ?: continue
                        if (!ip.contains(":")) return ip
                    }
                }
            }

            "Unknown"
        } catch (e: Exception) {
            "Unknown"
        }
    }
}
