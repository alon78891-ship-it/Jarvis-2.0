package com.example.service

class MathEvaluator {

    fun evaluateStringExpression(expression: String): String {
        return try {
            val formatted = expression
                .lowercase()
                .replace("multiplied by", "*")
                .replace("divided by", "/")
                .replace("plus", "+")
                .replace("minus", "-")
                .replace("into", "*")
                .replace("×", "*")
                .replace("÷", "/")
                .replace("x", "*")
                .replace(" ", "")

            if (formatted.isBlank()) return "Invalid calculation."
            if (!formatted.matches(Regex("""[0-9+\-*/().]+"""))) {
                return "Invalid calculation."
            }

            val result = Parser(formatted).parse()
            if (!result.isFinite()) return "Calculation error."

            if (result % 1.0 == 0.0) result.toLong().toString()
            else result.toString()
        } catch (_: Exception) {
            "Calculation error."
        }
    }

    private class Parser(private val input: String) {
        private var pos = 0

        fun parse(): Double {
            val value = expression()
            if (pos != input.length) throw IllegalArgumentException()
            return value
        }

        private fun expression(): Double {
            var value = term()
            while (pos < input.length) {
                when (input[pos]) {
                    '+' -> {
                        pos++
                        value += term()
                    }
                    '-' -> {
                        pos++
                        value -= term()
                    }
                    else -> return value
                }
            }
            return value
        }

        private fun term(): Double {
            var value = factor()
            while (pos < input.length) {
                when (input[pos]) {
                    '*' -> {
                        pos++
                        value *= factor()
                    }
                    '/' -> {
                        pos++
                        val divisor = factor()
                        if (divisor == 0.0) throw ArithmeticException()
                        value /= divisor
                    }
                    else -> return value
                }
            }
            return value
        }

        private fun factor(): Double {
            if (pos >= input.length) throw IllegalArgumentException()

            if (input[pos] == '+') {
                pos++
                return factor()
            }

            if (input[pos] == '-') {
                pos++
                return -factor()
            }

            if (input[pos] == '(') {
                pos++
                val value = expression()
                if (pos >= input.length || input[pos] != ')') {
                    throw IllegalArgumentException()
                }
                pos++
                return value
            }

            val start = pos
            while (pos < input.length &&
                (input[pos].isDigit() || input[pos] == '.')
            ) {
                pos++
            }

            if (start == pos) throw IllegalArgumentException()
            return input.substring(start, pos).toDouble()
        }
    }
}
