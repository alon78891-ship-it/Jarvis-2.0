package com.example.service

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.KeyEvent
import java.util.Locale

class DeviceController(private val context: Context) {

    private val cameraManager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val vibrator =
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    fun runFullHardwareDiagnostics(): String {
        return try {
            val batteryIntent = context.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val rawTemp =
                batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val temperature = rawTemp / 10.0
            val battery =
                batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1

            val am =
                context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memory)

            val available = memory.availMem / (1024.0 * 1024.0 * 1024.0)
            val total = memory.totalMem / (1024.0 * 1024.0 * 1024.0)

            buildString {
                append("Sir, system diagnostic complete. ")
                if (battery >= 0) append("Battery level is $battery percent. ")
                append(String.format(Locale.US, "Battery temperature is %.1f degrees Celsius. ", temperature))
                when {
                    temperature >= 45.0 -> append("Device temperature is high. ")
                    temperature >= 40.0 -> append("Device temperature is elevated. ")
                    else -> append("Thermal temperature appears normal. ")
                }
                append(String.format(Locale.US, "Available memory is %.2f GB out of %.2f GB.", available, total))
            }
        } catch (_: Exception) {
            "Sir, hardware diagnostics could not be completed."
        }
    }

    fun toggleFlashlight(enabled: Boolean) {
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            cameraManager.setTorchMode(cameraId, enabled)
        } catch (_: Exception) {
        }
    }

    fun adjustBrightness(level: Int) {
        try {
            val safe = level.coerceIn(0, 255)
            if (Settings.System.canWrite(context)) {
                Settings.System.putInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                    safe
                )
            }
        } catch (_: Exception) {
        }
    }

    fun injectMediaKey(keyCode: Int) {
        try {
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        } catch (_: Exception) {
        }
    }

    fun triggerPulseFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(
                        100L,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(100L)
            }
        } catch (_: Exception) {
        }
    }
}
