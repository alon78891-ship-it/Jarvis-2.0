package com.example.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log

class JarvisWifiRadar(private val context: Context) {
    private val appContext = context.applicationContext
    private val wifiManager = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val connectivityManager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun scanCurrentWifiSecurity(): String = try {
        val network = connectivityManager.activeNetwork
            ?: return "Sir, device currently kisi active network se connected nahi hai."
        val caps = connectivityManager.getNetworkCapabilities(network)
            ?: return "Sir, current network capabilities read nahi ho rahi hain."
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Sir, current connection Wi-Fi nahi hai."
        if (!hasLocationPermission()) return "Sir, Wi-Fi details ke liye Location permission required hai."

        val info = wifiManager.connectionInfo
        val ssid = info.ssid?.replace("\"", "")?.takeIf { it.isNotBlank() && it != "<unknown ssid>" } ?: "Unknown"
        val rssi = info.rssi
        val signal = when {
            rssi >= -50 -> "Excellent"
            rssi >= -60 -> "Very good"
            rssi >= -70 -> "Good"
            rssi >= -80 -> "Weak"
            else -> "Very weak"
        }
        "Sir, Wi-Fi audit complete. Network: $ssid. Link speed: ${info.linkSpeed} Mbps. Signal: $rssi dBm ($signal)."
    } catch (e: Exception) {
        Log.e("JARVIS_WIFI", "Current Wi-Fi audit failed", e)
        "Sir, Wi-Fi analysis complete nahi ho saka."
    }

    fun scanForVulnerablePerimeters(): String = try {
        if (!hasLocationPermission()) return "Sir, nearby Wi-Fi scan ke liye Location permission required hai."
        val results = wifiManager.scanResults
        if (results.isEmpty()) return "Sir, koi Wi-Fi scan result available nahi hai."

        val report = results.take(20).mapIndexed { index, result ->
            val caps = result.capabilities.uppercase()
            val security = when {
                caps.isBlank() -> "OPEN"
                caps.contains("WPA3") -> "WPA3"
                caps.contains("WPA2") || caps.contains("RSN") -> "WPA2/RSN"
                caps.contains("WPA") -> "WPA"
                caps.contains("WEP") -> "WEP"
                else -> "UNKNOWN"
            }
            val ssid = result.SSID.ifBlank { "<hidden>" }
            "${index + 1}. $ssid | BSSID ${result.BSSID} | CH ${frequencyToChannel(result.frequency)} | ${result.level} dBm | $security"
        }
        "Sir, Wi-Fi audit scan complete. ${results.size} network(s) detected.\n" +
            report.joinToString("\n") +
            "\n\nNote: Ye defensive audit hai; deauthentication, credential capture ya password cracking perform nahi karta."
    } catch (e: Exception) {
        Log.e("JARVIS_WIFI", "Wi-Fi scan failed", e)
        "Sir, environmental Wi-Fi scan complete nahi ho saka."
    }

    private fun frequencyToChannel(frequency: Int): String = when {
        frequency in 2412..2484 -> ((frequency - 2407) / 5).toString()
        frequency in 5000..5900 -> ((frequency - 5000) / 5).toString()
        frequency in 5955..7115 -> ((frequency - 5950) / 5).toString()
        else -> "?"
    }

    private fun hasLocationPermission(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    } else true
}
