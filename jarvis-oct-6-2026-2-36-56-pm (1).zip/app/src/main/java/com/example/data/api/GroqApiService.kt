package com.example.data.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GroqApiService(
    private var apiKey: String = DEFAULT_API_KEY
) {
    companion object {
        const val DEFAULT_API_KEY = "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"
        const val API_URL = "https://api.groq.com/openai/v1/chat/completions"
        const val DEFAULT_MODEL = "llama-3.1-8b-instant"
        const val VISION_MODEL = "llama-3.2-11b-vision-preview"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    fun updateApiKey(newKey: String) {
        if (newKey.isNotBlank()) {
            this.apiKey = newKey.trim()
        }
    }

    suspend fun chatCompletion(
        messages: List<Pair<String, String>>, // role to content
        userName: String = "Sir",
        model: String = DEFAULT_MODEL
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val rootObj = JSONObject()
            rootObj.put("model", model)

            val messagesArray = JSONArray()

            // System prompt to maintain JARVIS persona in Hindi/Hinglish
            val systemMsg = JSONObject()
            systemMsg.put("role", "system")
            systemMsg.put(
                "content",
                "Tum JARVIS ho — Tony Stark ka highly advanced, sharp aur witty AI Voice Assistant. Tum Hindi aur Hinglish me natural, respectful, confident aur smart tone me baat karte ho. User ka naam $userName hai. Har jawab short, smart aur to-the-point rakho (max 2-3 sentences), taaki voice pe sunne me natural lage. Kabhi robotic disclaimer mat bolo. User ke commands, sawalon aur baaton ka accurate aur intelligent jawab do."
            )
            messagesArray.put(systemMsg)

            for ((role, content) in messages) {
                val msg = JSONObject()
                msg.put("role", role)
                msg.put("content", content)
                messagesArray.put(msg)
            }

            rootObj.put("messages", messagesArray)
            rootObj.put("temperature", 0.7)
            rootObj.put("max_tokens", 350)

            val requestBody = rootObj.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(API_URL)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Groq API error (${response.code}): $bodyStr"))
                }

                val jsonResponse = JSONObject(bodyStr)
                val choices = jsonResponse.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    val message = choices.getJSONObject(0).getJSONObject("message")
                    val content = message.getString("content")
                    Result.success(content)
                } else {
                    Result.failure(Exception("No response choices returned by Groq"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun analyzeImageBase64(
        base64Jpeg: String,
        prompt: String = "Is image me kya hai? Hindi me 2 line me batao"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val rootObj = JSONObject()
            rootObj.put("model", VISION_MODEL)

            val messagesArray = JSONArray()
            val userMsg = JSONObject()
            userMsg.put("role", "user")

            val contentArray = JSONArray()

            val textPart = JSONObject()
            textPart.put("type", "text")
            textPart.put("text", prompt)
            contentArray.put(textPart)

            val imagePart = JSONObject()
            imagePart.put("type", "image_url")
            val imageUrlObj = JSONObject()
            imageUrlObj.put("url", "data:image/jpeg;base64,$base64Jpeg")
            imagePart.put("image_url", imageUrlObj)
            contentArray.put(imagePart)

            userMsg.put("content", contentArray)
            messagesArray.put(userMsg)

            rootObj.put("messages", messagesArray)

            val requestBody = rootObj.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(API_URL)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Vision API error: $bodyStr"))
                }

                val jsonResponse = JSONObject(bodyStr)
                val choices = jsonResponse.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    val message = choices.getJSONObject(0).getJSONObject("message")
                    Result.success(message.getString("content"))
                } else {
                    Result.failure(Exception("Vision model could not identify image"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
