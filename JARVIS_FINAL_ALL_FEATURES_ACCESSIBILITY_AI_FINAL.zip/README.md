# JARVIS FINAL ALL FEATURES

Personal Android JARVIS assistant project. This build includes the full command/control UI requested by the user plus a dedicated settings screen styled like the supplied reference screenshot.

## AI API Settings
- Separate **AI API SETTINGS** screen.
- Provider: Groq/Llama or OpenAI-compatible.
- Model field and optional custom API base URL.
- Masked API key input.
- Local-only key storage in Android SharedPreferences.
- Groq/OpenAI-compatible chat completion support.
- No API key is hard-coded into this project.

### Groq example
- Provider: Groq / Llama
- Model: `llama-3.3-70b-versatile` (change it if your account uses another model)
- Base URL: `https://api.groq.com/openai/v1`

### Image generation
Image generation requires an image-capable OpenAI provider/key in this build. Groq/Llama is used for chat and compatible vision models, not for image generation.

## Included controls
- YouTube, WhatsApp, Instagram, Facebook, Camera, Chrome, Settings, Gallery, Play Store, Gmail, Maps, Clock, Calculator, Files, Phone, Contacts, Messages, Spotify, Snapchat, Free Fire, BGMI.
- Close current screen, recent apps/background clean flow, home, back.
- Torch, Wi-Fi settings, Bluetooth settings, mobile-data settings, volume, brightness, screenshot permission flow, phone lock, silent mode.
- Battery, time, Dulalgram weather.
- Photo and video capture.
- Camera vision flow with compatible vision API.
- Contacts, dialer and WhatsApp contact automation.
- Hindi, English and Bengali speech recognition/TTS.
- Male/female TTS preference where the installed Android TTS engine provides matching voices.
- Memory and context storage.
- Emotion mode and personal voice-clone integration points.
- Background JARVIS foreground-service framework.
- Accessibility and notification-listener integration points.

## Android limitations
Android does not allow an ordinary app to silently force-stop arbitrary other apps or silently toggle some protected system settings such as mobile data. Accessibility, Device Admin, Notification Access and screen-capture permissions require explicit user approval. A true always-listening wake word and a consented voice-clone model require a real model/service connection.

## Build
The GitHub Actions workflow uses Java 17, Android SDK 35 and Gradle 8.10.2 and uploads a debug APK artifact named `Jarvis-FINAL-APK`.
