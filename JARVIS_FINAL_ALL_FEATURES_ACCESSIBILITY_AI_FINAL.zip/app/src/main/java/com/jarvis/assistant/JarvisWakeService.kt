package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class JarvisWakeService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channel = "jarvis_wake"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel, "JARVIS Background", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, channel).setContentTitle("JARVIS").setContentText("JARVIS background service is active").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(501, n)
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
