package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque
import java.util.Locale

class JarvisAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: JarvisAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        if (prefs.getBoolean("wa_pending", false) && event?.packageName?.toString() == "com.whatsapp") {
            val message = prefs.getString("wa_message", "") ?: ""
            if (message.isNotEmpty()) {
                val root = rootInActiveWindow ?: return
                val input = findEditable(root)
                if (input != null) { setText(input, message); clickWords(root, listOf("send")); prefs.edit().putBoolean("wa_pending", false).apply() }
            }
        }
    }
    fun execute(command: String): Boolean {
        val c=command.lowercase(Locale.ROOT).trim()
        return when {
            c.contains("stop scrolling") -> true
            c.contains("scroll down") || c.contains("next reel") || c.contains("reel next") -> swipe(true)
            c.contains("scroll up") || c.contains("previous reel") || c.contains("reel up") -> swipe(false)
            c.contains("unlike") -> clickWords(rootInActiveWindow ?: return false, listOf("unlike","remove like"))
            c.contains("like") -> clickWords(rootInActiveWindow ?: return false, listOf("like"))
            c.contains("comment") -> {
                val root=rootInActiveWindow ?: return false
                val text=c.substringAfter("comment", "").trim().removePrefix("on this video").trim()
                if (clickWords(root,listOf("comment","comments"))) {
                    if (text.isNotBlank()) { Thread.sleep(300); val r=rootInActiveWindow; if(r!=null){ findEditable(r)?.let{setText(it,text)}; clickWords(r,listOf("post","send","comment")) } }
                    true
                } else false
            }
            c.contains("pause") -> clickWords(rootInActiveWindow ?: return false, listOf("pause"))
            c.contains("play") -> clickWords(rootInActiveWindow ?: return false, listOf("play"))
            c.contains("stop") -> clickWords(rootInActiveWindow ?: return false, listOf("pause","stop"))
            else -> false
        }
    }
    private fun swipe(down:Boolean):Boolean { val dm=resources.displayMetrics; val x=dm.widthPixels*.5f; val y1=if(down)dm.heightPixels*.72f else dm.heightPixels*.30f; val y2=if(down)dm.heightPixels*.30f else dm.heightPixels*.72f; val p=Path().apply{moveTo(x,y1);lineTo(x,y2)}; return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,450)).build(),null,null) }
    private fun setText(n:AccessibilityNodeInfo,text:String){ val a=Bundle();a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,a) }
    private fun findEditable(n:AccessibilityNodeInfo):AccessibilityNodeInfo? { if(n.isEditable&&n.isVisibleToUser)return n; for(i in 0 until n.childCount)n.getChild(i)?.let{findEditable(it)?.let{return it}}; return null }
    private fun clickWords(root:AccessibilityNodeInfo,words:List<String>):Boolean { val q=ArrayDeque<AccessibilityNodeInfo>();q.add(root); while(q.isNotEmpty()){val n=q.removeFirst(); val t=((n.text?.toString()?:"")+" "+(n.contentDescription?.toString() ?: "")).lowercase(Locale.ROOT); if(n.isVisibleToUser&&words.any{w->t==w||t.contains(w)}){if(n.isClickable&&n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;var p=n.parent;repeat(4){if(p!=null&&p.isClickable&&p.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;p=p?.parent}};for(i in 0 until n.childCount)n.getChild(i)?.let(q::add)};return false }
    override fun onInterrupt() {}
    override fun onDestroy(){if(instance===this)instance=null;super.onDestroy()}
}
