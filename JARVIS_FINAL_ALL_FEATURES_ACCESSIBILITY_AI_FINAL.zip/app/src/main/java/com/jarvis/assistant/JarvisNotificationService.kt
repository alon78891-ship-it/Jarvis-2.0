package com.jarvis.assistant
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
class JarvisNotificationService: NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Notification access integration point for JARVIS.
        // The service becomes active only after the user enables Notification Access.
    }
}
