package com.jarvis.assistant

import android.Manifest
import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.util.Base64
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.WindowManager
import android.content.ContentValues
import android.provider.MediaStore
import android.widget.EditText
import android.widget.LinearLayout
import android.webkit.*
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import kotlin.concurrent.thread
import org.json.JSONObject

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val speechRequest = 7001
    private val screenCaptureRequest = 7002
    private val adminRequest = 7003
    private val visionRequest = 7004
    private var torch = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "AndroidJarvis")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        tts = TextToSpeech(this, this)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 9001)
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) setLanguage("hi") }

    private fun setLanguage(l: String) {
        val loc = when (l.lowercase()) {
            "bengali", "bn", "বাংলা" -> Locale("bn", "IN")
            "english", "en" -> Locale("en", "IN")
            else -> Locale("hi", "IN")
        }
        tts.language = loc
        prefs.edit().putString("tts_language", l).apply()
    }

    private fun speak(s: String) { runOnUiThread { tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis") } }
    private fun reply(s: String) { web.post { web.evaluateJavascript("window.jarvisReply(${JSONObject.quote(s)})", null) } }

    private fun weather() {
        thread {
            try {
                val geo = java.net.URL("https://geocoding-api.open-meteo.com/v1/search?name=Dulalgram&count=1&language=en&format=json").readText()
                val lat = Regex("\"latitude\":\\s*([-0-9.]+)").find(geo)?.groupValues?.get(1) ?: error("location")
                val lon = Regex("\"longitude\":\\s*([-0-9.]+)").find(geo)?.groupValues?.get(1) ?: error("location")
                val w = java.net.URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code").readText()
                val temp = Regex("\"temperature_2m\":\\s*([-0-9.]+)").find(w)?.groupValues?.get(1) ?: "?"
                val hum = Regex("\"relative_humidity_2m\":\\s*([0-9.]+)").find(w)?.groupValues?.get(1) ?: "?"
                val wind = Regex("\"wind_speed_10m\":\\s*([-0-9.]+)").find(w)?.groupValues?.get(1) ?: "?"
                reply("Dulalgram weather: $temp degrees, humidity $hum percent, wind $wind km/h.")
            } catch (_: Exception) { reply("Weather service is unavailable right now.") }
        }
    }

    private fun openPackage(pkg: String, label: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else reply("$label is not installed on this phone.")
    }

    private fun contactNumber(name: String, callback: (String?) -> Unit) {
        thread {
            var number: String? = null
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) number = it.getString(1) }
            runOnUiThread { callback(number) }
        }
    }

    private fun requestScreenCapture() {
        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(pm.createScreenCaptureIntent(), screenCaptureRequest)
    }

    private fun requestDeviceAdmin() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(this, JarvisDeviceAdminReceiver::class.java)
        if (!dpm.isAdminActive(cn)) {
            val i = Intent("android.app.action.ADD_DEVICE_ADMIN").apply {
                putExtra("android.app.extra.DEVICE_ADMIN", cn)
                putExtra("android.app.extra.ADD_EXPLANATION", "JARVIS needs device-admin permission only when you ask it to lock the phone.")
            }
            startActivityForResult(i, adminRequest)
        } else dpm.lockNow()
    }

    inner class Bridge {
        @JavascriptInterface fun speak(s: String) = this@MainActivity.speak(s)
        @JavascriptInterface fun language(l: String) = setLanguage(l)
        @JavascriptInterface fun voice(gender: String) {
            val wantMale = gender.lowercase().contains("male") && !gender.lowercase().contains("female")
            val voices = tts.voices.orEmpty().filter { it.locale.language == tts.voice?.locale?.language }
            val selected = voices.firstOrNull { v ->
                val n = v.name.lowercase()
                (wantMale && (n.contains("male") || n.contains("man"))) || (!wantMale && (n.contains("female") || n.contains("woman")))
            } ?: voices.firstOrNull()
            if (selected != null) tts.voice = selected
            reply("Voice preference updated. Available voices depend on the Android TTS engine.")
        }
        @JavascriptInterface fun startSpeechInput() {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.getString("tts_language", "hi-IN"))
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening")
            }
            startActivityForResult(i, speechRequest)
        }
        @JavascriptInterface fun openApp(n: String) {
            val key = n.lowercase().trim()
            val apps = mapOf(
                "youtube" to ("com.google.android.youtube" to "YouTube"), "whatsapp" to ("com.whatsapp" to "WhatsApp"),
                "instagram" to ("com.instagram.android" to "Instagram"), "facebook" to ("com.facebook.katana" to "Facebook"),
                "chrome" to ("com.android.chrome" to "Chrome"), "spotify" to ("com.spotify.music" to "Spotify"),
                "snapchat" to ("com.snapchat.android" to "Snapchat"), "gmail" to ("com.google.android.gm" to "Gmail"),
                "maps" to ("com.google.android.apps.maps" to "Maps"), "play store" to ("com.android.vending" to "Play Store"),
                "playstore" to ("com.android.vending" to "Play Store"), "bgmi" to ("com.pubg.imobile" to "BGMI"),
                "free fire" to ("com.dts.freefireth" to "Free Fire")
            )
            val pair = apps[key]
            if (pair != null) openPackage(pair.first, pair.second) else when (key) {
                "camera" -> cameraPhoto(); "gallery" -> gallery(); "settings" -> settings(); "clock" -> startActivity(Intent("android.intent.action.SHOW_ALARMS"));
                "calculator" -> startActivity(Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CALCULATOR"));
                "file manager" -> startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) });
                "phone" -> startActivity(Intent(Intent.ACTION_DIAL)); "contacts" -> startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI));
                "messages" -> startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING));
                else -> reply("I cannot find an installed app for $n.")
            }
        }
        @JavascriptInterface fun camera() = cameraPhoto()
        @JavascriptInterface fun cameraPhoto() { startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)) }
        @JavascriptInterface fun cameraVideo() { startActivity(Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE)) }
        @JavascriptInterface fun gallery() { startActivity(Intent(Intent.ACTION_VIEW).apply { type = "image/*" }) }
        @JavascriptInterface fun settings() { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        @JavascriptInterface fun maps(q: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q)))) }
        @JavascriptInterface fun call(n: String) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
        @JavascriptInterface fun callContact(name: String) { contactNumber(name) { if (it != null) call(it!!) else reply("Contact not found: $name") } }
        @JavascriptInterface fun whatsapp(n: String, msg: String) {
            val u = "https://wa.me/" + n.filter { it.isDigit() } + "?text=" + Uri.encode(msg)
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        }
        @JavascriptInterface fun whatsappContact(name: String, msg: String) {
            contactNumber(name) { if (it != null) whatsappAutoSend(it!!, msg) else reply("Contact not found: $name") }
        }
        @JavascriptInterface fun whatsappAutoSend(number: String, msg: String) {
            prefs.edit().putString("wa_message", msg).putBoolean("wa_pending", true).apply()
            whatsapp(number, msg)
        }
        @JavascriptInterface fun weather() = this@MainActivity.weather()
        @JavascriptInterface fun torch(on: Boolean) {
            try {
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                if (id != null) { cm.setTorchMode(id, on); torch = on; reply(if (on) "Torch on." else "Torch off.") }
            } catch (_: Exception) { reply("Torch control is unavailable.") }
        }
        @JavascriptInterface fun volume(delta: Int) {
            val a = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC); val cur = a.getStreamVolume(AudioManager.STREAM_MUSIC)
            a.setStreamVolume(AudioManager.STREAM_MUSIC, (cur + delta).coerceIn(0, max), AudioManager.FLAG_SHOW_UI)
        }
        @JavascriptInterface fun mute() { (getSystemService(AUDIO_SERVICE) as AudioManager).ringerMode = AudioManager.RINGER_MODE_SILENT }
        @JavascriptInterface fun brightness(delta: Int) {
            val lp = window.attributes
            val current = if (lp.screenBrightness < 0) 128 else (lp.screenBrightness * 255).toInt()
            lp.screenBrightness = (current + delta).coerceIn(10, 255) / 255f; window.attributes = lp
        }
        @JavascriptInterface fun setBrightness(value: Int) { val lp = window.attributes; lp.screenBrightness = value.coerceIn(10,255)/255f; window.attributes=lp }
        @JavascriptInterface fun wifi() { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        @JavascriptInterface fun bluetooth() { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        @JavascriptInterface fun mobileData() { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        @JavascriptInterface fun dnd() { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        @JavascriptInterface fun notifications() { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        @JavascriptInterface fun lockPhone() = requestDeviceAdmin()
        @JavascriptInterface fun screenshot() = requestScreenCapture()
        @JavascriptInterface fun home() { if (JarvisAccessibilityService.instance != null) JarvisAccessibilityService.instance!!.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) else startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }
        @JavascriptInterface fun recent() { if (JarvisAccessibilityService.instance != null) JarvisAccessibilityService.instance!!.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS) else startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }
        @JavascriptInterface fun back() { if (JarvisAccessibilityService.instance != null) JarvisAccessibilityService.instance!!.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) else onBackPressed() }
        @JavascriptInterface fun accessibilityCommand(command: String) { runOnUiThread { val svc=JarvisAccessibilityService.instance; if(svc==null){ reply("JARVIS Accessibility permission is required. Enable JARVIS in Android Accessibility settings."); accessibilitySettings(); return@runOnUiThread }; if(!svc.execute(command)) reply("That UI control was not found in the current app. App versions can change accessibility labels.") } }
        @JavascriptInterface fun setVolumePercent(percent: Int) { val a=getSystemService(AUDIO_SERVICE) as AudioManager; val max=a.getStreamMaxVolume(AudioManager.STREAM_MUSIC); val p=percent.coerceIn(0,100); a.setStreamVolume(AudioManager.STREAM_MUSIC,max*p/100,AudioManager.FLAG_SHOW_UI); reply("Volume set to $p percent.") }
        @JavascriptInterface fun youtubeSearch(query: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(query)))) }
        @JavascriptInterface fun accessibilitySettings() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        @JavascriptInterface fun wakeWordSettings() { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
        @JavascriptInterface fun backgroundClean() { recent(); reply("Opened recent apps. Android does not allow a normal app to force-stop every other app.") }
        @JavascriptInterface fun battery() { val b=getSystemService(BATTERY_SERVICE) as BatteryManager; reply("Battery is ${b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent.") }
        @JavascriptInterface fun time() { reply(java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())) }
        @JavascriptInterface fun contacts(q: String) { contactNumber(q) { if (it != null) reply("$q: $it") else reply("Contact not found.") } }
        @JavascriptInterface fun remember(k: String, v: String) { prefs.edit().putString("mem_$k", v).apply() }
        @JavascriptInterface fun recall(k: String): String = prefs.getString("mem_$k", "") ?: ""
        @JavascriptInterface fun saveApiKey(k: String) { if (k.isNotBlank()) prefs.edit().putString("ai_key", k.trim()).apply() }
        @JavascriptInterface fun getApiKey(): String = prefs.getString("ai_key", prefs.getString("openai_key", "") ?: "") ?: ""
        @JavascriptInterface fun hasApiKey(): Boolean = getApiKey().isNotBlank()
        @JavascriptInterface fun clearApiKey() { prefs.edit().remove("ai_key").remove("openai_key").apply() }
        @JavascriptInterface fun setAIConfig(provider: String, model: String, baseUrl: String) {
            prefs.edit().putString("ai_provider", provider).putString("ai_model", model).putString("ai_base_url", baseUrl).apply()
        }
        @JavascriptInterface fun batterySilent() {
            val b = getSystemService(BATTERY_SERVICE) as BatteryManager
            val pct = b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            web.post { web.evaluateJavascript("document.getElementById('batteryTop').textContent='🔋 ${pct}%';", null) }
        }
        @JavascriptInterface fun openApiKeySettings() {
            val input = EditText(this@MainActivity)
            input.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            input.hint = "Paste your personal API key"
            input.setText(prefs.getString("openai_key", ""))
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(40, 8, 40, 0)
                addView(input)
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("JARVIS AI API Key")
                .setMessage("Your key is stored locally on this device. Never share it with anyone.")
                .setView(box)
                .setPositiveButton("Save") { _, _ ->
                    val key = input.text.toString().trim()
                    if (key.isNotBlank()) prefs.edit().putString("openai_key", key).apply()
                    reply(if (key.isNotBlank()) "AI API key saved locally." else "No key entered.")
                }
                .setNeutralButton("Clear") { _, _ ->
                    prefs.edit().remove("openai_key").apply()
                    reply("AI API key cleared.")
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        @JavascriptInterface fun aiChat(prompt: String) {
            val key = getApiKey()
            if (key.isBlank()) { reply("AI API key is not set. Open JARVIS Settings and add your key."); return }
            val provider = prefs.getString("ai_provider", "groq") ?: "groq"
            val model = prefs.getString("ai_model", if (provider == "groq") "llama-3.3-70b-versatile" else "gpt-4o-mini") ?: "llama-3.3-70b-versatile"
            val base = (prefs.getString("ai_base_url", if (provider == "groq") "https://api.groq.com/openai/v1" else "https://api.openai.com/v1") ?: "").trimEnd('/')
            thread {
                try {
                    val conn = URL("$base/chat/completions").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 20000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    conn.setRequestProperty("Authorization", "Bearer $key")
                    conn.setRequestProperty("Content-Type", "application/json")
                    val body = JSONObject().apply {
                        put("model", model)
                        put("messages", org.json.JSONArray().put(JSONObject().put("role", "system").put("content", "You are JARVIS, a helpful personal Android assistant. Answer naturally and concisely. Support Hindi, English and Bengali based on the user's language."))
                            .put(JSONObject().put("role", "user").put("content", prompt)))
                        put("temperature", 0.7)
                    }.toString()
                    conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                    val response = stream.bufferedReader().use { it.readText() }
                    if (conn.responseCode !in 200..299) {
                        val msg = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                        reply("AI API error: ${msg ?: "HTTP ${conn.responseCode}"}")
                    } else {
                        val answer = JSONObject(response).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                        reply(if (!answer.isNullOrBlank()) answer else "AI returned an empty response.")
                    }
                    conn.disconnect()
                } catch (e: Exception) { reply("AI connection failed: ${e.message ?: "network error"}") }
            }
        }
        @JavascriptInterface fun generateImage(prompt: String) {
            val provider = prefs.getString("ai_provider", "groq") ?: "groq"
            val key = getApiKey()
            if (key.isBlank()) { reply("Add an AI API key in JARVIS Settings first."); return }
            if (provider != "openai") { reply("AI image generation needs an OpenAI image-capable API key/provider. Your Groq/Llama key can power JARVIS chat, but not image generation."); return }
            val base = (prefs.getString("ai_base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1").trimEnd('/')
            thread {
                try {
                    val conn = URL("$base/images/generations").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 120000; conn.doOutput = true
                    conn.setRequestProperty("Authorization", "Bearer $key"); conn.setRequestProperty("Content-Type", "application/json")
                    val body = JSONObject().put("model", "gpt-image-1").put("prompt", prompt).put("size", "1024x1024").toString()
                    conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                    val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                    if (conn.responseCode !in 200..299) { reply("Image API error: HTTP ${conn.responseCode}"); return@thread }
                    val b64 = JSONObject(response).optJSONArray("data")?.optJSONObject(0)?.optString("b64_json")
                    if (b64.isNullOrBlank()) { reply("Image API returned no image data."); return@thread }
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "JARVIS_${System.currentTimeMillis()}.png"); put(MediaStore.Images.Media.MIME_TYPE, "image/png"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JARVIS") }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri == null) { reply("Could not save generated image."); return@thread }
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
                    reply("Image generated and saved to Pictures/JARVIS.")
                } catch (e: Exception) { reply("Image generation failed: ${e.message ?: "network error"}") }
            }
        }
        @JavascriptInterface fun vision() {
            val key = getApiKey()
            if (key.isBlank()) { reply("Add an AI API key first, then use Camera Vision."); return }
            reply("Camera Vision is ready. Tap the camera and allow the capture; the vision model can then describe the captured frame when a compatible vision model is configured.")
            startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE), visionRequest)
        }
        @JavascriptInterface fun voiceClone() { reply("Authorized personal voice-clone integration point ready. Add your own consented voice model/service.") }
        @JavascriptInterface fun emotion(mode: String) { prefs.edit().putString("emotion_mode", mode).apply(); reply("Emotion-aware mode: $mode") }
        @JavascriptInterface fun startWakeService() { startService(Intent(this@MainActivity, JarvisWakeService::class.java)); reply("JARVIS background service started. A true wake-word model still needs to be connected.") }
    }


    private fun sendVisionFrame(bitmap: Bitmap) {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("ai_key", "").orEmpty()
        if (key.isBlank()) { reply("AI API key is not set."); return }
        val provider = prefs.getString("ai_provider", "groq") ?: "groq"
        val base = (prefs.getString("ai_base_url", if (provider == "groq") "https://api.groq.com/openai/v1" else "https://api.openai.com/v1") ?: "").trimEnd('/')
        val model = prefs.getString("ai_vision_model", if (provider == "groq") "meta-llama/llama-4-scout-17b-16e-instruct" else "gpt-4o-mini") ?: "gpt-4o-mini"
        thread {
            try {
                val stream = java.io.ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                val b64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                val content = org.json.JSONArray()
                    .put(JSONObject().put("type", "text").put("text", "Describe this camera image. Read visible text if possible and identify the main objects. Keep the answer concise."))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
                val messages = org.json.JSONArray().put(JSONObject().put("role", "user").put("content", content))
                val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.2).toString()
                val conn = URL("$base/chat/completions").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 60000; conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $key"); conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) { reply("Vision API error: HTTP ${conn.responseCode}"); return@thread }
                val answer = JSONObject(response).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                reply(answer ?: "Vision model returned no description.")
            } catch (e: Exception) { reply("Camera vision failed: ${e.message ?: "network error"}") }
        }
    }

    @Deprecated("legacy")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == speechRequest && c == RESULT_OK) {
            val s = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            web.evaluateJavascript("window.jarvisNativeResult(${JSONObject.quote(s)})", null)
        } else if (r == visionRequest && c == RESULT_OK) {
            val bmp = d?.extras?.get("data") as? Bitmap
            if (bmp == null) { reply("Camera frame was not returned by the camera app."); return }
            sendVisionFrame(bmp)
        }
    }
}
