# JARVIS WhatsApp Contact Fix

Fixes the case where WhatsApp automation works for a raw phone number but fails for a saved contact name.

## What changed
- Resolves a spoken contact name directly from Android `ContactsContract`.
- Tries exact name match, then partial name match.
- Falls back to the JARVIS contact database.
- Never sends an unresolved contact name to `wa.me`.
- Returns a clear error if no phone number can be found.

## Required permission
`READ_CONTACTS` must be granted to JARVIS.

## Test
Use a real saved contact name:
`Ruhan ko WhatsApp pe Hello bhejo`

The app should resolve Ruhan's phone number first, then open the WhatsApp chat and perform the configured Accessibility send flow.
