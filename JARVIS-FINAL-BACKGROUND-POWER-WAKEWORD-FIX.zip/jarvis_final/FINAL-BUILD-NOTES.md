# JARVIS 2.0 — Final feature source pack

Included: Contacts import/call/WhatsApp, WhatsApp accessibility auto-send, camera quick open, permissions hub, Accessibility screen/media controls, YouTube/Instagram-style voice media controls, background service scaffold, English/Hindi/Bengali language selection, male/female TTS profiles, feeling styles, image-generator web launcher, offline/local command intent handling, weather/torch/phone controls and security-safe screen lock actions.

Android limitations: secure PIN/password/biometric unlock cannot be bypassed; Accessibility and runtime permissions require explicit user approval; continuous camera/voice use follows Android foreground-service/privacy rules; voice cloning is not included as an impersonation mechanism; image generation opens a web generator rather than embedding a secret API key.

Build: push this source to GitHub and run the included Actions workflow. It builds a debug APK with Gradle 9.3.1, Android 36 and a generated debug keystore.
