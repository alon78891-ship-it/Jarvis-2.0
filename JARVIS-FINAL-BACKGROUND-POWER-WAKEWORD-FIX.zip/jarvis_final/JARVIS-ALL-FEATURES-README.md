# JARVIS 2.0 — All requested features pack

This source is based on the latest JARVIS contacts + WhatsApp source.

## Added in this pack
- Bengali (`bn` / বাংলা) TTS language alongside Hindi and English.
- Male/Female voice profile preference.
- Voice feelings: neutral, happy, excited, calm, confident, friendly, sad, serious.
- Camera quick command.
- App permissions quick command.
- Accessibility permission quick command.
- JARVIS Accessibility service for Home/Back/Recents, scrolling and media play/pause/next.
- Voice commands for YouTube/Instagram-style media controls.
- Offline Brain status/intent for local commands.
- Image generator command using a web image generator URL.
- Expanded app opener support scaffold.
- Existing Contacts import + direct call + WhatsApp automation retained.
- Existing background foreground service retained.

## Android security limitations
- A normal app cannot bypass the user's PIN/password/biometric authentication. The "lock" feature only opens Android security settings or uses permitted device actions.
- Continuous background camera/vision requires Android camera foreground-service rules and explicit user permission. This pack does not secretly record or keep the camera running.
- Accessibility control requires the user to explicitly enable JARVIS in Android Accessibility settings.
- A true neural voice clone requires a dedicated voice-cloning model/service and a user's authorized voice sample. This pack provides male/female TTS profile controls, not an impersonation/cloning model.
- Image generation is opened through a web generator URL; it does not embed a secret API key in the APK.

## Build
Use the existing GitHub Actions workflow for the project. Do not put API keys directly into source code.
