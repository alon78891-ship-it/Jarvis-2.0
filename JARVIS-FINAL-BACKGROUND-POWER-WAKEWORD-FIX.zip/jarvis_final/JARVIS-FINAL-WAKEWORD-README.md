# JARVIS Final Wake-Word / Personal AI Assistant Upgrade

This source includes the existing JARVIS voice + all-app control project plus a Google-Assistant-style wake-word loop:

- Say **Hey JARVIS** / **Hey Jervis** / **Hi JARVIS** / **Hello JARVIS**.
- JARVIS responds: **Yes Boss, boliye.**
- Then it listens for the next command and sends it through the existing JARVISSmartCommander.
- A combined command also works, e.g. **Hey JARVIS, YouTube kholo**.
- Hindi/Bengali wake-word variants are included where Android speech recognition returns them.
- The foreground background-assistant service keeps the wake loop alive while the user has enabled it and granted microphone permission.

## Important Android limitation

This is not the same as Google's privileged system hotword engine. A normal Android app cannot guarantee a screen-off, always-listening hotword on every phone. Battery optimization, microphone restrictions, OEM background limits, and the installed speech-recognition provider can interrupt it. The app must keep its foreground microphone service active and the user must grant microphone permission.

## Build

Use the existing GitHub Actions workflow in `.github/workflows/build.yml`. The workflow builds a debug APK and uploads it as an artifact.
