# JARVIS Background Power / Hey JARVIS Fix

This patch fixes the #34-style problem where Background Power could be switched on
but JARVIS would not speak or listen.

Changes:
- Background Power checks microphone permission before starting the microphone foreground service.
- If permission is missing, the UI requests RECORD_AUDIO first.
- The background service explicitly reports a missing microphone permission instead of failing silently.
- Hey JARVIS wake-word mode starts after the foreground service is established.
- Existing WhatsApp message parsing fix is preserved.

Test after building:
1. Give JARVIS microphone permission.
2. Turn Background Power ON.
3. You should hear the background online message.
4. Say: "Hey JARVIS".
5. JARVIS should answer: "Yes Boss, boliye."
6. Then say a simple command such as "flash on".

Android/OEM battery restrictions can still affect long-term background microphone operation.
