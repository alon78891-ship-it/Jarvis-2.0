package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.db.ContactEntity
import com.example.data.db.MemoryEntity
import com.example.data.db.NoteEntity
import com.example.data.db.TaskEntity
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyanLight
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGoldAccent
import com.example.ui.theme.JarvisGreenOnline
import com.example.ui.theme.JarvisRedAlert
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

// ==========================================
// 1. ALL 37 COMMANDS CHEAT SHEET DIALOG
// ==========================================
data class CommandItem(
    val category: String,
    val command: String,
    val description: String
)

val ALL_37_COMMANDS = listOf(
    // Essentials
    CommandItem("Weather", "weather Dulalgram", "Get live weather report"),
    CommandItem("Wikipedia", "wiki Albert Einstein", "Read Wikipedia summary in Hindi"),
    CommandItem("Translation", "translate How are you", "Translate text to Hindi/English"),
    CommandItem("Calculation", "calculate 25 * 40 + 150", "Math calculation evaluation"),
    CommandItem("Time", "time", "Current time display and readout"),
    CommandItem("Date", "date", "Today's date display and readout"),

    // Apps & System Control
    CommandItem("App Opener", "open camera", "Launch Camera app"),
    CommandItem("App Opener", "open gallery", "Launch Gallery/Photos app"),
    CommandItem("App Opener", "open whatsapp", "Launch WhatsApp"),
    CommandItem("App Opener", "open instagram", "Launch Instagram"),
    CommandItem("App Opener", "open youtube", "Launch YouTube"),
    CommandItem("App Opener", "open chrome", "Launch Chrome / Google"),
    CommandItem("App Opener", "open calculator", "Launch Calculator"),
    CommandItem("App Opener", "open settings", "Open System Settings"),

    // Phone & Communication
    CommandItem("Call", "call Rohan", "Call contact or number directly"),
    CommandItem("WhatsApp Msg", "whatsapp hello to 9876543210", "Send direct WhatsApp message"),
    CommandItem("WhatsApp Chat", "open whatsapp Rohan", "Open WhatsApp conversation"),
    CommandItem("Alarm", "alarm 07:30", "Set device alarm clock"),
    CommandItem("Battery", "battery", "Check battery level & status"),
    CommandItem("Flashlight ON", "flash on", "Turn on device torch"),
    CommandItem("Flashlight OFF", "flash off", "Turn off device torch"),
    CommandItem("Location", "location", "Open Google Maps location"),
    CommandItem("Camera", "take photo", "Quick camera capture"),
    CommandItem("Volume Up", "volume up", "Increase system volume"),
    CommandItem("Volume Down", "volume down", "Decrease system volume"),
    CommandItem("Clipboard", "type Welcome to JARVIS", "Copy text to clipboard"),
    CommandItem("Search", "google latest AI news", "Search on Google"),
    CommandItem("YouTube", "play song Believer", "Play or search song on YouTube"),

    // Memory & Notes (Brain)
    CommandItem("Note", "note Buy Groceries today", "Save text note to local storage"),
    CommandItem("Show Notes", "show notes", "Read and show all saved notes"),
    CommandItem("Task", "add task Morning workout", "Add task to todo list"),
    CommandItem("Show Tasks", "show tasks", "Read and show all tasks"),
    CommandItem("Remember", "remember wifi = password123", "Store key-value memory"),
    CommandItem("Recall", "what is wifi", "Retrieve stored memory or wiki"),
    CommandItem("Contacts", "add contact Rohan 9876543210", "Save contact to phonebook"),

    // AI & Advanced
    CommandItem("AI Vision", "what do you see", "Analyze photo with AI"),
    CommandItem("AI Chat", "Tum kya kar sakte ho?", "Conversational Groq Llama AI in Hindi"),
    CommandItem("Help", "help", "List capabilities and commands")
)

@Composable
fun QuickCommandsDialog(
    onDismiss: () -> Unit,
    onRunCommand: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .testTag("quick_commands_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(JarvisCyanPrimary))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "COMMAND PROTOCOLS",
                            color = JarvisCyanLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "37 Voice & System Capabilities",
                            color = JarvisTextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ALL_37_COMMANDS) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(JarvisSurfaceElevated)
                                .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    onRunCommand(item.command)
                                    onDismiss()
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(JarvisCyanPrimary.copy(alpha = 0.15f))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = item.category.uppercase(),
                                            color = JarvisCyanPrimary,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = item.command,
                                        color = JarvisTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.description,
                                    color = JarvisTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Run",
                                tint = JarvisCyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. NOTES DIALOG
// ==========================================
@Composable
fun NotesDialog(
    notes: List<NoteEntity>,
    onAddNote: (String) -> Unit,
    onDeleteNote: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var newNoteText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .testTag("notes_manager_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(JarvisSurfaceBorder))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SAVED NOTES (${notes.size})",
                        color = JarvisCyanLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newNoteText,
                        onValueChange = { newNoteText = it },
                        placeholder = { Text("Add new note...", color = JarvisTextMuted, fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary,
                            focusedBorderColor = JarvisCyanPrimary,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedContainerColor = JarvisSurfaceElevated,
                            unfocusedContainerColor = JarvisSurfaceElevated
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (newNoteText.isNotBlank()) {
                                onAddNote(newNoteText)
                                newNoteText = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(JarvisCyanPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (notes.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Koi notes nahi hain. Say 'note ...' to add.", color = JarvisTextMuted, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(notes, key = { it.id }) { note ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(JarvisSurfaceElevated)
                                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = note.content,
                                    color = JarvisTextPrimary,
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onDeleteNote(note.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = JarvisRedAlert, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. TASKS DIALOG
// ==========================================
@Composable
fun TasksDialog(
    tasks: List<TaskEntity>,
    onAddTask: (String) -> Unit,
    onToggleTask: (TaskEntity) -> Unit,
    onDeleteTask: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var newTaskText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .testTag("tasks_manager_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(JarvisSurfaceBorder))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TASKS & TO-DO (${tasks.size})",
                        color = JarvisCyanLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newTaskText,
                        onValueChange = { newTaskText = it },
                        placeholder = { Text("Add new task...", color = JarvisTextMuted, fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary,
                            focusedBorderColor = JarvisCyanPrimary,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedContainerColor = JarvisSurfaceElevated,
                            unfocusedContainerColor = JarvisSurfaceElevated
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (newTaskText.isNotBlank()) {
                                onAddTask(newTaskText)
                                newTaskText = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(JarvisCyanPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (tasks.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Koi tasks nahi hain. Say 'add task ...' to add.", color = JarvisTextMuted, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(tasks, key = { it.id }) { task ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(JarvisSurfaceElevated)
                                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                                    .clickable { onToggleTask(task) }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = "Toggle",
                                    tint = if (task.isCompleted) JarvisGreenOnline else JarvisTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = task.title,
                                    color = if (task.isCompleted) JarvisTextMuted else JarvisTextPrimary,
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onDeleteTask(task.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = JarvisRedAlert, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. MEMORY / BRAIN DIALOG
// ==========================================
@Composable
fun MemoryBrainDialog(
    memories: List<MemoryEntity>,
    onAddMemory: (String, String) -> Unit,
    onDeleteMemory: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var keyText by remember { mutableStateOf("") }
    var valueText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .testTag("memory_brain_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(JarvisSurfaceBorder))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BRAIN MEMORY (${memories.size})",
                        color = JarvisCyanLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = keyText,
                        onValueChange = { keyText = it },
                        placeholder = { Text("Key (e.g. wifi)", color = JarvisTextMuted, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary,
                            focusedBorderColor = JarvisCyanPrimary,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedContainerColor = JarvisSurfaceElevated,
                            unfocusedContainerColor = JarvisSurfaceElevated
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    OutlinedTextField(
                        value = valueText,
                        onValueChange = { valueText = it },
                        placeholder = { Text("Value", color = JarvisTextMuted, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary,
                            focusedBorderColor = JarvisCyanPrimary,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedContainerColor = JarvisSurfaceElevated,
                            unfocusedContainerColor = JarvisSurfaceElevated
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = {
                            if (keyText.isNotBlank() && valueText.isNotBlank()) {
                                onAddMemory(keyText, valueText)
                                keyText = ""
                                valueText = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(JarvisCyanPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (memories.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No memory entries yet. Say 'remember X = Y'.", color = JarvisTextMuted, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(memories, key = { it.key }) { mem ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(JarvisSurfaceElevated)
                                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = mem.key,
                                        color = JarvisCyanLight,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = mem.value,
                                        color = JarvisTextPrimary,
                                        fontSize = 13.sp
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteMemory(mem.key) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = JarvisRedAlert, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. CONTACTS DIALOG
// ==========================================
@Composable
fun ContactsDialog(
    contacts: List<ContactEntity>,
    onAddContact: (String, String) -> Unit,
    onDeleteContact: (String) -> Unit,
    onCallContact: (String) -> Unit,
    onWhatsAppContact: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var nameText by remember { mutableStateOf("") }
    var phoneText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .testTag("contacts_manager_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(JarvisSurfaceBorder))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "JARVIS CONTACTS (${contacts.size})",
                        color = JarvisCyanLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = nameText,
                        onValueChange = { nameText = it },
                        placeholder = { Text("Name", color = JarvisTextMuted, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary,
                            focusedBorderColor = JarvisCyanPrimary,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedContainerColor = JarvisSurfaceElevated,
                            unfocusedContainerColor = JarvisSurfaceElevated
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    OutlinedTextField(
                        value = phoneText,
                        onValueChange = { phoneText = it },
                        placeholder = { Text("Phone Number", color = JarvisTextMuted, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary,
                            focusedBorderColor = JarvisCyanPrimary,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedContainerColor = JarvisSurfaceElevated,
                            unfocusedContainerColor = JarvisSurfaceElevated
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = {
                            if (nameText.isNotBlank() && phoneText.isNotBlank()) {
                                onAddContact(nameText, phoneText)
                                nameText = ""
                                phoneText = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(JarvisCyanPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(contacts, key = { it.name }) { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(JarvisSurfaceElevated)
                                .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contact.name,
                                    color = JarvisTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = contact.phoneNumber,
                                    color = JarvisTextSecondary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onCallContact(contact.phoneNumber) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = "Call", tint = JarvisGreenOnline, modifier = Modifier.size(18.dp))
                                }
                                IconButton(
                                    onClick = { onWhatsAppContact(contact.phoneNumber) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "WhatsApp", tint = JarvisCyanPrimary, modifier = Modifier.size(18.dp))
                                }
                                IconButton(
                                    onClick = { onDeleteContact(contact.name) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = JarvisRedAlert, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. SETTINGS DIALOG
// ==========================================
@Composable
fun SettingsDialog(
    currentUserName: String,
    currentGroqKey: String,
    currentLanguage: String,
    isBackgroundActive: Boolean,
    onToggleBackgroundService: () -> Unit,
    onSaveName: (String) -> Unit,
    onSaveGroqKey: (String) -> Unit,
    onSaveLanguage: (String) -> Unit,
    onSaveVoiceProfile: (String, String) -> Unit = { _, _ -> },
    onDismiss: () -> Unit
) {
    var nameInput by remember { mutableStateOf(currentUserName) }
    var keyInput by remember { mutableStateOf(currentGroqKey) }
    var selectedLang by remember { mutableStateOf(currentLanguage) }
    var selectedGender by remember { mutableStateOf("female") }
    var selectedFeeling by remember { mutableStateOf("neutral") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .testTag("jarvis_settings_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(JarvisSurfaceBorder))
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "JARVIS CONFIGURATION",
                        color = JarvisCyanLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = JarvisTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Background Chatting Power Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(JarvisSurfaceElevated)
                        .border(
                            1.dp,
                            if (isBackgroundActive) JarvisCyanPrimary else JarvisSurfaceBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onToggleBackgroundService() }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (isBackgroundActive) JarvisCyanPrimary else JarvisTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Background Chatting Power",
                                color = JarvisTextPrimary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Direct notification reply, background voice responses & lockscreen controls.",
                            color = JarvisTextSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = isBackgroundActive,
                        onCheckedChange = { onToggleBackgroundService() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = JarvisCyanPrimary,
                            uncheckedThumbColor = JarvisTextSecondary,
                            uncheckedTrackColor = JarvisSurfaceBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // User Name
                Text(text = "User Name (e.g. Boss / Sir)", color = JarvisTextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = JarvisTextPrimary,
                        unfocusedTextColor = JarvisTextPrimary,
                        focusedBorderColor = JarvisCyanPrimary,
                        unfocusedBorderColor = JarvisSurfaceBorder,
                        focusedContainerColor = JarvisSurfaceElevated,
                        unfocusedContainerColor = JarvisSurfaceElevated
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Language selection
                Text(text = "Voice Synthesis Language", color = JarvisTextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { selectedLang = "hi" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedLang == "hi") JarvisCyanPrimary else JarvisSurfaceElevated,
                            contentColor = if (selectedLang == "hi") Color.Black else JarvisTextSecondary
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Hindi / हिन्दी")
                    }
                    Button(
                        onClick = { selectedLang = "en" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedLang == "en") JarvisCyanPrimary else JarvisSurfaceElevated,
                            contentColor = if (selectedLang == "en") Color.Black else JarvisTextSecondary
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("English")
                    }
                }

                // Bengali
                Button(
                    onClick = { selectedLang = "bn" },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedLang == "bn") JarvisCyanPrimary else JarvisSurfaceElevated,
                        contentColor = if (selectedLang == "bn") Color.Black else JarvisTextSecondary
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Bengali / বাংলা")
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(text = "Voice", color = JarvisTextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { selectedGender = "male" }, modifier = Modifier.weight(1f)) { Text("👨 Male") }
                    Button(onClick = { selectedGender = "female" }, modifier = Modifier.weight(1f)) { Text("👩 Female") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("neutral","happy","excited","calm","confident","friendly","sad","serious").forEach { mood ->
                        Button(onClick = { selectedFeeling = mood }, modifier = Modifier.weight(1f)) { Text(mood.take(5)) }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Groq API Key
                Text(text = "Groq Llama API Key", color = JarvisTextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = JarvisTextPrimary,
                        unfocusedTextColor = JarvisTextPrimary,
                        focusedBorderColor = JarvisCyanPrimary,
                        unfocusedBorderColor = JarvisSurfaceBorder,
                        focusedContainerColor = JarvisSurfaceElevated,
                        unfocusedContainerColor = JarvisSurfaceElevated
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onSaveName(nameInput)
                        onSaveGroqKey(keyInput)
                        onSaveLanguage(selectedLang)
                            onSaveVoiceProfile(selectedGender, selectedFeeling)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisCyanPrimary, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
