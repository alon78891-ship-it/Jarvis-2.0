package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JarvisVoiceState
import com.example.ui.theme.JarvisCyanLight
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGoldAccent
import com.example.ui.theme.JarvisRedAlert
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun VoiceControlBar(
    voiceState: JarvisVoiceState,
    amplitude: Float,
    onMicClick: () -> Unit,
    onSendCommand: (String) -> Unit,
    onPickImage: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenTasks: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenContacts: () -> Unit,
    onToggleBackgroundService: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by remember { mutableStateOf("") }
    val isListening = voiceState == JarvisVoiceState.LISTENING

    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(JarvisSurface.copy(alpha = 0.95f))
            .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .imePadding()
    ) {
        // Horizontal quick chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QuickChip(label = "⚡ BG Chat", onClick = onToggleBackgroundService, tag = "chip_bg_chat")
            QuickChip(label = "📝 Notes", onClick = onOpenNotes, tag = "chip_notes")
            QuickChip(label = "✅ Tasks", onClick = onOpenTasks, tag = "chip_tasks")
            QuickChip(label = "🧠 Memory", onClick = onOpenMemory, tag = "chip_memory")
            QuickChip(label = "📞 Contacts", onClick = onOpenContacts, tag = "chip_contacts")
            QuickChip(label = "⛅ Weather", onClick = { onSendCommand("weather Dulalgram") }, tag = "chip_weather")
            QuickChip(label = "🔋 Battery", onClick = { onSendCommand("battery") }, tag = "chip_battery")
            QuickChip(label = "💡 Torch ON", onClick = { onSendCommand("flash on") }, tag = "chip_torch_on")
            QuickChip(label = "🔦 Torch OFF", onClick = { onSendCommand("flash off") }, tag = "chip_torch_off")
            QuickChip(label = "📷 Camera", onClick = { onSendCommand("open camera") }, tag = "chip_camera")
            QuickChip(label = "🎨 Image", onClick = { onSendCommand("generate image futuristic JARVIS") }, tag = "chip_image")
            QuickChip(label = "⚙️ Permission", onClick = { onSendCommand("permissions") }, tag = "chip_permissions")
            QuickChip(label = "♿ Screen Control", onClick = { onSendCommand("accessibility permission") }, tag = "chip_accessibility")
            QuickChip(label = "🧠 Offline", onClick = { onSendCommand("offline brain") }, tag = "chip_offline")
            QuickChip(label = "🎬 Media", onClick = { onSendCommand("video pause") }, tag = "chip_media")
            QuickChip(label = "🎙️ Voice", onClick = { onSendCommand("female voice") }, tag = "chip_voice")
            QuickChip(label = "❤️ Feeling", onClick = { onSendCommand("confident feeling") }, tag = "chip_feeling")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main input bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Camera / Vision button
            IconButton(
                onClick = onPickImage,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(JarvisSurfaceElevated)
                    .border(1.dp, JarvisSurfaceBorder, CircleShape)
                    .testTag("vision_camera_button")
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "AI Vision photo",
                    tint = JarvisCyanPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Text Input Field
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = {
                    Text(
                        text = if (isListening) "Listening to voice..." else "Command or question in Hindi/English...",
                        color = JarvisTextSecondary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("command_input_field"),
                textStyle = TextStyle(
                    color = JarvisTextPrimary,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Default
                ),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisCyanPrimary,
                    unfocusedBorderColor = JarvisSurfaceBorder,
                    focusedContainerColor = JarvisSurfaceElevated,
                    unfocusedContainerColor = JarvisSurfaceElevated,
                    focusedTextColor = JarvisTextPrimary,
                    unfocusedTextColor = JarvisTextPrimary,
                    disabledTextColor = JarvisTextPrimary,
                    cursorColor = JarvisCyanPrimary
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (textInput.isNotBlank()) {
                        onSendCommand(textInput)
                        textInput = ""
                    }
                })
            )

            Spacer(modifier = Modifier.width(8.dp))

            if (textInput.isNotBlank()) {
                // Send text button
                IconButton(
                    onClick = {
                        onSendCommand(textInput)
                        textInput = ""
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(JarvisCyanPrimary)
                        .testTag("send_command_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else {
                // Mic Button with pulsating halo when listening
                Box(contentAlignment = Alignment.Center) {
                    if (isListening) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(JarvisGoldAccent.copy(alpha = 0.25f))
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (isListening) JarvisGoldAccent else JarvisCyanPrimary)
                            .clickable { onMicClick() }
                            .testTag("mic_toggle_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Mic else Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickChip(
    label: String,
    onClick: () -> Unit,
    tag: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(JarvisSurfaceElevated)
            .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .testTag(tag)
    ) {
        Text(
            text = label,
            color = JarvisTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace
        )
    }
}
