package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.KeyEvent
import android.media.AudioManager

/**
 * JARVIS screen/media controller. User must explicitly enable this service in
 * Android Accessibility settings. It never bypasses device authentication.
 */
class JarvisAccessibilityService : AccessibilityService() {
    companion object {
        private var instance: JarvisAccessibilityService? = null
        private const val PREFS = "jarvis_accessibility"
        private const val KEY_ACTION = "pending_action"

        fun isEnabled(): Boolean = instance != null

        fun requestAction(context: android.content.Context, action: String): Boolean {
            context.getSharedPreferences(PREFS, 0).edit().putString(KEY_ACTION, action).apply()
            val service = instance
            if (service != null) {
                service.performPendingAction()
                return true
            }
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = (serviceInfo ?: AccessibilityServiceInfo()).apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        performPendingAction()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        performPendingAction()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private fun performPendingAction() {
        val prefs = getSharedPreferences(PREFS, 0)
        val action = prefs.getString(KEY_ACTION, null) ?: return
        prefs.edit().remove(KEY_ACTION).apply()

        when (action) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "scroll_up" -> findScrollable(rootInActiveWindow)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            "scroll_down" -> findScrollable(rootInActiveWindow)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            "play_pause" -> sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            "next" -> sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            "previous" -> sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "stop" -> sendMediaKey(KeyEvent.KEYCODE_MEDIA_STOP)
            "screenshot" -> {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                }
            }
            "close" -> performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun sendMediaKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
