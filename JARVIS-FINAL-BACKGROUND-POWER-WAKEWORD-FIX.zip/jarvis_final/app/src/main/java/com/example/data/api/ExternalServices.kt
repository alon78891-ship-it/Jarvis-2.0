package com.example.data.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

class ExternalServices {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // 1. WEATHER (from wttr.in as in Python script)
    suspend fun fetchWeather(city: String): String = withContext(Dispatchers.IO) {
        val targetCity = if (city.isBlank()) "Dulalgram" else city.trim()
        val encoded = URLEncoder.encode(targetCity, StandardCharsets.UTF_8.toString())
        val url = "https://wttr.in/$encoded?format=3"

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "curl/7.88.1")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()?.trim() ?: ""
                    if (body.isNotBlank() && !body.contains("Unknown location", ignoreCase = true)) {
                        return@withContext body
                    }
                }
            }
            "Mausam ki jankari nahi mili for $targetCity"
        } catch (e: Exception) {
            "Weather check error: ${e.localizedMessage ?: "Internet connection error"}"
        }
    }

    // 2. WIKIPEDIA SUMMARY (Hindi with English fallback)
    suspend fun fetchWikiSummary(query: String): String = withContext(Dispatchers.IO) {
        val cleaned = query.trim()
        if (cleaned.isBlank()) return@withContext "Wikipedia par kya khojna hai?"

        val encoded = URLEncoder.encode(cleaned, StandardCharsets.UTF_8.toString())

        // Try Hindi first (as in Python script: wikipedia.set_lang("hi"))
        val hindiResult = tryWikiApi("https://hi.wikipedia.org/api/rest_v1/page/summary/$encoded")
        if (hindiResult != null && hindiResult.isNotBlank()) {
            return@withContext hindiResult
        }

        // Search query in Hindi
        val searchHindi = searchWikiAndGetExtract("hi", cleaned)
        if (searchHindi != null && searchHindi.isNotBlank()) {
            return@withContext searchHindi
        }

        // Fallback to English
        val englishResult = tryWikiApi("https://en.wikipedia.org/api/rest_v1/page/summary/$encoded")
        if (englishResult != null && englishResult.isNotBlank()) {
            return@withContext englishResult
        }

        val searchEnglish = searchWikiAndGetExtract("en", cleaned)
        if (searchEnglish != null && searchEnglish.isNotBlank()) {
            return@withContext searchEnglish
        }

        "Wikipedia par '$cleaned' ke baare me koi jankari nahi mili."
    }

    private fun tryWikiApi(url: String): String? {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "JARVIS-Assistant/1.0 (Android)")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val json = JSONObject(response.body?.string() ?: "")
                    val extract = json.optString("extract")
                    if (extract.isNotBlank()) {
                        // Limit to ~2 sentences
                        val sentences = extract.split(". ")
                        if (sentences.size > 2) {
                            "${sentences[0]}. ${sentences[1]}."
                        } else {
                            extract
                        }
                    } else null
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun searchWikiAndGetExtract(lang: String, query: String): String? {
        return try {
            val searchUrl = "https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=" +
                    URLEncoder.encode(query, "UTF-8") +
                    "&format=json&srlimit=1"

            val request = Request.Builder()
                .url(searchUrl)
                .header("User-Agent", "JARVIS-Assistant/1.0 (Android)")
                .build()

            val title = client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val json = JSONObject(response.body?.string() ?: "")
                val searchList = json.optJSONObject("query")?.optJSONArray("search")
                if (searchList != null && searchList.length() > 0) {
                    searchList.getJSONObject(0).optString("title")
                } else null
            } ?: return null

            val summaryUrl = "https://$lang.wikipedia.org/api/rest_v1/page/summary/" +
                    URLEncoder.encode(title, "UTF-8")
            tryWikiApi(summaryUrl)
        } catch (e: Exception) {
            null
        }
    }

    // 3. TRANSLATOR (Auto to English or Hindi)
    suspend fun translateText(text: String, targetLang: String = "en"): String = withContext(Dispatchers.IO) {
        val cleaned = text.trim()
        if (cleaned.isBlank()) return@withContext "Translate karne ke liye text dejiye."

        try {
            val encoded = URLEncoder.encode(cleaned, StandardCharsets.UTF_8.toString())
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$targetLang&dt=t&q=$encoded"

            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val rawJson = response.body?.string() ?: ""
                    val root = JSONArray(rawJson)
                    val sentences = root.optJSONArray(0)
                    if (sentences != null) {
                        val sb = StringBuilder()
                        for (i in 0 until sentences.length()) {
                            val part = sentences.optJSONArray(i)
                            if (part != null) {
                                sb.append(part.optString(0))
                            }
                        }
                        val result = sb.toString().trim()
                        if (result.isNotBlank()) return@withContext result
                    }
                }
            }
            "Translation me error aaya."
        } catch (e: Exception) {
            "Translate error: ${e.localizedMessage ?: "Unknown error"}"
        }
    }
}
