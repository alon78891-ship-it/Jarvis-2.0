package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.net.URLEncoder

class WhatsAppAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var attempts = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        launchPendingIfAny()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() == WHATSAPP_PACKAGE) {
            if (hasPendingRequest()) scheduleSendAttempt()
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(SEND_TOKEN)
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun launchPendingIfAny() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val url = prefs.getString(KEY_URL, null) ?: return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage(WHATSAPP_PACKAGE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            scheduleSendAttempt()
        } catch (_: Exception) {
            prefs.edit().remove(KEY_URL).apply()
        }
    }

    private fun scheduleSendAttempt() {
        handler.removeCallbacksAndMessages(SEND_TOKEN)
        attempts = 0
        handler.postAtTime({ tryClickSend() }, SEND_TOKEN, android.os.SystemClock.uptimeMillis() + 900)
    }

    private fun tryClickSend() {
        if (!hasPendingRequest()) return
        attempts++
        val root = rootInActiveWindow
        if (root != null && root.packageName?.toString() == WHATSAPP_PACKAGE) {
            val sendNode = findSendNode(root)
            if (sendNode != null && sendNode.isVisibleToUser && sendNode.isEnabled) {
                if (sendNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    clearPending()
                    return
                }
            }
        }
        if (attempts < MAX_ATTEMPTS) {
            handler.postDelayed({ tryClickSend() }, 500)
        }
    }

    private fun findSendNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        try {
            root.findAccessibilityNodeInfosByViewId(WHATSAPP_SEND_ID).firstOrNull()?.let { return it }
        } catch (_: Exception) {}

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
            val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            val id = node.viewIdResourceName?.lowercase().orEmpty()
            if ((text == "send" || desc == "send" || id.endsWith(":id/send")) && node.isClickable) {
                return node
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    private fun hasPendingRequest(): Boolean =
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(KEY_URL)

    private fun clearPending() {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_URL).apply()
        handler.removeCallbacksAndMessages(SEND_TOKEN)
    }

    companion object {
        private const val PREFS = "jarvis_whatsapp_automation"
        private const val KEY_URL = "pending_url"
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_SEND_ID = "com.whatsapp:id/send"
        private const val MAX_ATTEMPTS = 20
        private val SEND_TOKEN = Any()
        private var instance: WhatsAppAutomationService? = null

        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, WhatsAppAutomationService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ).orEmpty()
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }

        fun queueAndStart(context: Context, number: String, message: String): Boolean {
            var formatted = number.replace(" ", "").replace("-", "")
            if (!formatted.startsWith("+") && !formatted.startsWith("91") && formatted.length == 10) {
                formatted = "91" + formatted
            }
            formatted = formatted.removePrefix("+")
            val encodedMsg = URLEncoder.encode(message, "UTF-8")
            val url = "https://wa.me/" + formatted + "?text=" + encodedMsg

            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_URL, url)
                .apply()

            val enabled = isEnabled(context)
            if (!enabled) {
                try {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (_: Exception) {}
                return false
            }

            try {
                instance?.launchPendingIfAny()
                    ?: context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        setPackage(WHATSAPP_PACKAGE)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
            } catch (_: Exception) {}
            return true
        }
    }
}
