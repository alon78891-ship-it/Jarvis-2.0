package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.ui.JarvisMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    private var warned20 = false
    private var warned10 = false
    private var warnedFull = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

                val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
                viewModel.updateDeviceStatus()

                if (status == BatteryManager.BATTERY_STATUS_FULL) {
                    if (!warnedFull) {
                        viewModel.speak("Battery full ho gayi hai.")
                        warnedFull = true
                    }
                } else {
                    warnedFull = false
                    if (pct <= 10 && !warned10) {
                        viewModel.speak("Battery sirf $pct percent hai. Charger connect karein.")
                        warned10 = true
                    } else if (pct <= 20 && !warned20) {
                        viewModel.speak("Battery $pct percent hai.")
                        warned20 = true
                    }
                    if (pct > 25) {
                        warned20 = false
                        warned10 = false
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        setContent {
            MyApplicationTheme {
                JarvisMainScreen(viewModel = viewModel)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {}
    }
}
